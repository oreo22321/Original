#!/usr/bin/env node
// vscode-web server: static files + private login + server-side AI proxy (no dependencies).
// 必須の設定は無し。APP_PASSWORD 未設定なら自動生成して起動ログに表示 (.vsw-password に保存)。
// 任意 Env: PORT, HOST, APP_PASSWORD, AI_API_KEY, AI_BASE_URL, AI_MODEL, AI_INLINE_MODEL, AI_MODELS(許可モデル, * で全許可), AI_MAX_TOKENS, SESSION_SECRET, TRUST_PROXY(自動判定), COOKIE_SECURE, CSP=off
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import os from 'node:os';
const execFileAsync = promisify(execFile);
// luau バイナリのパスを環境変数か自動検索で解決
function findLuau() {
  if (process.env.LUAU_BIN) return process.env.LUAU_BIN;
  const candidates = ['/usr/local/bin/luau', '/usr/bin/luau', '/app/bin/luau'];
  for (const c of candidates) { try { if (fs.statSync(c).isFile()) return c; } catch {} }
  return null;
}
const LUAU_BIN = findLuau();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const loadEnv = (f) => { try { for (const l of fs.readFileSync(f, 'utf8').split('\n')) { const m = /^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/.exec(l); if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, ''); } } catch {} };
loadEnv(path.join(__dirname, '.env'));
const PORT = +(process.env.PORT || 8787), HOST = process.env.HOST || '0.0.0.0';
let PASS = process.env.APP_PASSWORD || '', PASS_GENERATED = false;
if (!PASS) {
  const pf = path.join(__dirname, '.vsw-password');
  try { PASS = fs.readFileSync(pf, 'utf8').trim(); } catch {}
  if (!PASS) { PASS = crypto.randomBytes(12).toString('base64url'); try { fs.writeFileSync(pf, PASS, { mode: 0o600 }); } catch {} }
  PASS_GENERATED = true;
}
const TRUST_PROXY = process.env.TRUST_PROXY ? process.env.TRUST_PROXY === '1' : !!(process.env.RENDER || process.env.FLY_APP_NAME || process.env.RAILWAY_ENVIRONMENT || process.env.K_SERVICE || process.env.DYNO);
const AI_KEY = process.env.AI_API_KEY || '';
const AI_BASE = (process.env.AI_BASE_URL || 'https://api.x.ai/v1').replace(/\/+$/, '');
const AI_MODEL = process.env.AI_MODEL || 'grok-4';
const AI_MODELS = (process.env.AI_MODELS || '').split(',').map((x) => x.trim()).filter(Boolean);
const AI_ANY_MODEL = AI_MODELS.includes('*');
const AI_ALLOWED = new Set([AI_MODEL, process.env.AI_INLINE_MODEL, ...AI_MODELS].filter(Boolean));
const AI_MAX_TOKENS = +(process.env.AI_MAX_TOKENS || 8192);
const SECRET = process.env.SESSION_SECRET || crypto.createHash('sha256').update('vsw:' + PASS + ':' + AI_KEY).digest('hex');
const ROOT = fs.existsSync(path.join(__dirname, 'dist')) ? path.join(__dirname, 'dist') : __dirname;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ttf': 'font/ttf', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8', '.ico': 'image/x-icon' };

const sign = (v) => crypto.createHmac('sha256', SECRET).update(v).digest('base64url');
const SESSION_DAYS = 180;
// token = exp.sig ; sig binds the expiry to the current password (changing APP_PASSWORD logs every device out)
const PW_TAG = crypto.createHash('sha256').update('pw:' + PASS).digest('hex').slice(0, 16);
const makeToken = () => { const exp = Date.now() + SESSION_DAYS * 864e5; return `${exp}.${sign(exp + '.' + PW_TAG)}`; };
const tokenExp = (t) => { if (!t) return 0; const [exp, sig] = t.split('.'); if (!exp || !sig || +exp < Date.now()) return 0; const want = sign(exp + '.' + PW_TAG); return sig.length === want.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(want)) ? +exp : 0; };
const validToken = (t) => tokenExp(t) > 0;
const isSecure = (req) => process.env.COOKIE_SECURE === '1' || req.headers['x-forwarded-proto'] === 'https' || !!req.headers['cf-visitor'] || !!req.socket.encrypted;
const sessionCookie = (req, v, maxAge) => `vsw_session=${v}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${isSecure(req) ? '; Secure' : ''}`;
// login rate limit: 5 free attempts, then exponential lockout (30s, 60s, 2m … max 60m)
// forwarded headers are only trusted when the request comes from a local reverse proxy / tunnel (otherwise they could be spoofed to dodge the lockout)
const clientIp = (req) => { const ra = req.socket.remoteAddress || ''; const local = ra === '127.0.0.1' || ra === '::1' || ra === '::ffff:127.0.0.1'; return local || TRUST_PROXY ? String(req.headers['cf-connecting-ip'] || (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || ra) : ra; };
function lockLeft(a) { return a && a.until > Date.now() ? a.until - Date.now() : 0; }
function recordFail(ip) { const a = attempts.get(ip) || { n: 0, until: 0, t: Date.now() }; a.n++; a.t = Date.now(); if (a.n >= 5) a.until = Date.now() + Math.min(60 * 60e3, 30e3 * 2 ** (a.n - 5)); attempts.set(ip, a); return a; }
setInterval(() => { const now = Date.now(); for (const [k, a] of attempts) if (now - a.t > 24 * 3600e3) attempts.delete(k); }, 3600e3).unref();
const safeEq = (a, b) => { const x = crypto.createHash('sha256').update(a).digest(), y = crypto.createHash('sha256').update(b).digest(); return crypto.timingSafeEqual(x, y); };
const cookies = (req) => Object.fromEntries((req.headers.cookie || '').split(';').map((c) => c.trim().split('=')).filter((x) => x[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join('='))]));
const isLocal = (req) => { const a = req.socket.remoteAddress || ''; return !req.headers['x-forwarded-for'] && !req.headers['cf-connecting-ip'] && (a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1'); };
function authed(req) {
  if (!PASS) return true;
  if (validToken(cookies(req).vsw_session)) return true;
  const h = req.headers.authorization || '';
  if (h.startsWith('Bearer ') && safeEq(h.slice(7), PASS)) return true;
  if (h.startsWith('Basic ')) { const [, p] = Buffer.from(h.slice(6), 'base64').toString().split(/:(.*)/s); if (p !== undefined && safeEq(p, PASS)) return true; }
  return false;
}
const CSP = "default-src 'self'; script-src 'self' 'wasm-unsafe-eval' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self' https: http: https://cdn.jsdelivr.net; worker-src 'self' blob:; manifest-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'";
const SEC = { 'X-Robots-Tag': 'noindex, nofollow, noarchive', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY', ...(process.env.CSP === 'off' ? {} : { 'Content-Security-Policy': CSP }) };
const send = (res, code, body, headers = {}) => { res.writeHead(code, { ...SEC, ...headers }); res.end(body); };
const attempts = new Map();
const LOGIN = (err = '') => `<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><meta name="theme-color" content="#0b0d12"><title>vscode — ログイン</title>
<style>*{box-sizing:border-box}html,body{margin:0;height:100%;background:#0b0d12;color:#c9ced8;font:15px -apple-system,BlinkMacSystemFont,"Segoe UI","Hiragino Sans","Noto Sans JP",sans-serif;overflow:hidden}
body{display:flex;align-items:center;justify-content:center}body:before,body:after{content:"";position:fixed;width:70vmax;height:70vmax;border-radius:50%;filter:blur(80px);opacity:.3;animation:a 16s ease-in-out infinite}body:before{background:#5b8cff;left:-25vmax;top:-30vmax}body:after{background:#a78bfa;right:-30vmax;bottom:-35vmax;animation-delay:-8s}
@keyframes a{50%{transform:translate(8%,6%) scale(1.25)}}@keyframes p{from{opacity:0;transform:translateY(24px) scale(.96)}to{opacity:1;transform:none}}@keyframes f{50%{transform:translateY(-6px)}}@keyframes s{to{background-position:200% 0}}
form{position:relative;z-index:1;width:min(370px,90vw);display:flex;flex-direction:column;gap:12px;padding:34px 28px;border-radius:26px;background:#121622b3;border:1px solid #ffffff1c;-webkit-backdrop-filter:blur(24px);backdrop-filter:blur(24px);box-shadow:0 30px 80px #000a;animation:p .7s cubic-bezier(.32,.72,0,1)}
.logo{display:flex;align-items:center;gap:12px;margin-bottom:4px}.logo svg{width:40px;height:40px;animation:f 4s ease-in-out infinite;filter:drop-shadow(0 6px 18px #6ea8ffaa)}
h1{font-size:22px;font-weight:700;margin:0;background:linear-gradient(120deg,#6ea8ff,#a78bfa,#5eead4,#6ea8ff);background-size:200% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:s 6s linear infinite}p{margin:0 0 6px;color:#8a93a3;font-size:13px}
input,button{height:48px;border-radius:13px;font-size:16px;font-family:inherit}input{background:#0b0d12cc;color:#fff;border:1px solid #ffffff1f;padding:0 15px;outline:none;transition:border-color .2s,box-shadow .25s}input:focus{border-color:#6ea8ff;box-shadow:0 0 0 4px #5b8cff33}
button{background:linear-gradient(120deg,#5b8cff,#8b5cf6,#5b8cff);background-size:200% 100%;color:#fff;border:0;cursor:pointer;font-weight:600;box-shadow:0 8px 24px #5b8cff66;transition:transform .18s cubic-bezier(.32,.72,0,1),background-position .4s}button:hover{background-position:100% 0}button:active{transform:scale(.95)}.e{color:#f38b8b;min-height:18px;font-size:13px}.n{font-size:12px;color:#6c7586;text-align:center}
@media(prefers-reduced-motion:reduce){*,:before,:after{animation:none!important}}</style></head>
<body><form method="post" action="./login"><div class="logo"><svg viewBox="0 0 16 16"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6ea8ff"/><stop offset="1" stop-color="#a78bfa"/></linearGradient></defs><rect x="2.5" y="2.5" width="11" height="11" rx="3" transform="rotate(15 8 8)" fill="url(#g)"/><rect x="6.5" y="6.5" width="3" height="3" rx="1" transform="rotate(15 8 8)" fill="#fff"/></svg><h1>vscode</h1></div><p>Lua / Luau エディタ — プライベート</p><input type="password" name="password" placeholder="パスワード" autofocus autocomplete="current-password" enterkeyhint="go"><div class="e">${err}</div><button>ログイン</button><div class="n">この端末では ${SESSION_DAYS} 日間ログインしたままになります</div></form></body></html>`;

function readBody(req, limit = 2e6) { return new Promise((resolve, reject) => { let n = 0; const chunks = []; req.on('data', (c) => { n += c.length; if (n > limit) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); }); req.on('end', () => resolve(Buffer.concat(chunks))); req.on('error', reject); }); }

// ---- Luau サーバーサイド実行 (/api/luau) ----
const LUAU_TIMEOUT = +(process.env.LUAU_TIMEOUT || 10000); // ms
const LUAU_MAX_OUTPUT = 64 * 1024; // 64KB
async function luauRun(req, res) {
  const JJ = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };
  if (req.method !== 'POST') return send(res, 405, JSON.stringify({ error: 'method not allowed' }), JJ);
  if (!LUAU_BIN) return send(res, 503, JSON.stringify({ error: 'luau バイナリが見つかりません。Dockerfile で LUAU_BIN を設定してください。', luauAvailable: false }), JJ);
  let body;
  try { body = JSON.parse((await readBody(req, 128 * 1024)).toString()); } catch { return send(res, 400, JSON.stringify({ error: 'bad json' }), JJ); }
  const code = typeof body.code === 'string' ? body.code : '';
  if (!code.trim()) return send(res, 200, JSON.stringify({ stdout: '', stderr: '', exitCode: 0 }), JJ);
  // 一時ファイルに書き出して実行
  const tmp = path.join(os.tmpdir(), 'luau_' + crypto.randomBytes(8).toString('hex') + '.luau');
  try {
    fs.writeFileSync(tmp, code, { mode: 0o600 });
    const { stdout, stderr } = await execFileAsync(LUAU_BIN, [tmp], {
      timeout: LUAU_TIMEOUT,
      maxBuffer: LUAU_MAX_OUTPUT,
      env: { PATH: process.env.PATH || '/usr/local/bin:/usr/bin:/bin' },
    });
    return send(res, 200, JSON.stringify({ stdout: stdout.slice(0, LUAU_MAX_OUTPUT), stderr: stderr.slice(0, 8192), exitCode: 0, luauAvailable: true }), JJ);
  } catch (e) {
    const isTimeout = e.killed || e.code === 'ETIMEDOUT' || (e.signal === 'SIGTERM');
    return send(res, 200, JSON.stringify({
      stdout: (e.stdout || '').slice(0, LUAU_MAX_OUTPUT),
      stderr: isTimeout ? '⏱ タイムアウト (${LUAU_TIMEOUT/1000}秒超過)' : (e.stderr || e.message || '').slice(0, 8192),
      exitCode: e.code ?? 1,
      luauAvailable: true,
    }), JJ);
  } finally {
    try { fs.unlinkSync(tmp); } catch {}
  }
}

async function proxyAI(req, res) {
  if (!AI_KEY) return send(res, 503, JSON.stringify({ error: { message: 'サーバーに AI_API_KEY が設定されていません' } }), { 'Content-Type': 'application/json' });
  if (!PASS && !isLocal(req)) return send(res, 403, JSON.stringify({ error: { message: 'APP_PASSWORD 未設定のため、AI プロキシはローカルからのみ利用できます' } }), { 'Content-Type': 'application/json' });
  let body;
  try { body = JSON.parse((await readBody(req)).toString()); } catch { return send(res, 400, JSON.stringify({ error: { message: 'bad json' } }), { 'Content-Type': 'application/json' }); }
  const model = typeof body.model === 'string' && body.model && (AI_ANY_MODEL || AI_ALLOWED.has(body.model)) ? body.model : AI_MODEL;
  const out = { model, messages: Array.isArray(body.messages) ? body.messages : [], stream: !!body.stream };
  for (const k of ['temperature', 'top_p', 'stop']) if (body[k] !== undefined) out[k] = body[k];
  out.max_tokens = Math.min(Math.max(1, Math.floor(+body.max_tokens) || AI_MAX_TOKENS), AI_MAX_TOKENS);
  const ac = new AbortController();
  res.on('close', () => { if (!res.writableFinished) ac.abort(); });
  try {
    const up = await fetch(AI_BASE + '/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${AI_KEY}` }, body: JSON.stringify(out), signal: ac.signal });
    res.writeHead(up.status, { ...SEC, 'Content-Type': up.headers.get('content-type') || 'application/json', 'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no' });
    if (!up.body) return res.end();
    for await (const chunk of up.body) res.write(chunk);
    res.end();
  } catch (e) {
    if (ac.signal.aborted) return;
    if (!res.headersSent) send(res, 502, JSON.stringify({ error: { message: 'upstream error: ' + e.message } }), { 'Content-Type': 'application/json' }); else res.end();
  }
}

// ---- static files: in-memory cache + precompressed (brotli/gzip) + ETag/304 ----
const COMPRESSIBLE = /text|javascript|json|svg|css|manifest|font\/ttf/;
const fileCache = new Map();
const brotli = (b) => new Promise((ok, ng) => zlib.brotliCompress(b, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 9, [zlib.constants.BROTLI_PARAM_SIZE_HINT]: b.length } }, (e, r) => (e ? ng(e) : ok(r))));
const gzip = (b) => new Promise((ok, ng) => zlib.gzip(b, { level: 9 }, (e, r) => (e ? ng(e) : ok(r))));
const statSafe = (f) => { try { return fs.statSync(f); } catch { return null; } };
function entry(file, st) {
  let e = fileCache.get(file);
  if (!e || e.mtime !== st.mtimeMs || e.size !== st.size) {
    const raw = fs.readFileSync(file);
    e = { mtime: st.mtimeMs, size: st.size, raw, etag: '"' + crypto.createHash('sha1').update(raw).digest('base64url').slice(0, 20) + '"', enc: {} };
    fileCache.set(file, e);
  }
  return e;
}
const encoded = (e, k) => (e.enc[k] ||= (k === 'br' ? brotli(e.raw) : gzip(e.raw)));
async function serveStatic(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'method not allowed', { Allow: 'GET, HEAD' });
  let p; try { p = decodeURIComponent(url.pathname); } catch { return send(res, 400, 'bad request'); }
  if (p.includes('\0')) return send(res, 400, 'bad request');
  if (p.endsWith('/')) p += 'index.html';
  let file = path.normalize(path.join(ROOT, p));
  if (file !== ROOT && !file.startsWith(ROOT + path.sep)) return send(res, 403, 'forbidden');
  if (/(^|\/)(server\.js|\.env|\.vsw-password|package(-lock)?\.json)$/.test(p)) return send(res, 404, 'not found');
  let st = statSafe(file);
  if (!st || st.isDirectory()) {
    if (path.extname(p)) return send(res, 404, 'not found', { 'Cache-Control': 'no-store' }); // 存在しない asset に index.html を返さない (SW 汚染防止)
    file = path.join(ROOT, 'index.html'); st = statSafe(file);
    if (!st) return send(res, 404, 'not found');
  }
  const type = MIME[path.extname(file)] || 'application/octet-stream';
  const e = entry(file, st);
  const headers = { 'Content-Type': type, ETag: e.etag, 'Cache-Control': /\/assets\//.test(file.replace(/\\/g, '/')) ? 'public, max-age=31536000, immutable' : 'no-cache', Vary: 'Accept-Encoding' };
  if (req.headers['if-none-match'] === e.etag) return send(res, 304, '', headers);
  let body = e.raw;
  if (COMPRESSIBLE.test(type) && e.raw.length > 1024) {
    const ae = req.headers['accept-encoding'] || '';
    const k = /\bbr\b/.test(ae) ? 'br' : /\bgzip\b/.test(ae) ? 'gzip' : '';
    if (k) { body = await encoded(e, k); headers['Content-Encoding'] = k; }
  }
  headers['Content-Length'] = body.length;
  send(res, 200, req.method === 'HEAD' ? '' : body, headers);
}
async function warmup() { // 起動直後に圧縮を済ませ、初回アクセスを速くする
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((x) => (x.isDirectory() ? walk(path.join(d, x.name)) : [path.join(d, x.name)]));
  try { for (const f of walk(ROOT)) { const t = MIME[path.extname(f)]; const st = statSafe(f); if (!t || !st || !COMPRESSIBLE.test(t) || st.size <= 1024) continue; const e = entry(f, st); await encoded(e, 'br'); await encoded(e, 'gzip'); } } catch {}
}


// ---- データ保存: ディスク(+履歴50件) と、任意で GitHub への自動バックアップ ----
let DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
try { fs.mkdirSync(path.join(DATA_DIR, 'versions'), { recursive: true }); } catch { DATA_DIR = '/tmp/vsw-data'; try { fs.mkdirSync(path.join(DATA_DIR, 'versions'), { recursive: true }); } catch {} }
const FS_FILE = path.join(DATA_DIR, 'fs.json'), VER_DIR = path.join(DATA_DIR, 'versions');
const GH_TOKEN = process.env.GITHUB_TOKEN || '', GH_REPO = process.env.GITHUB_REPO || '', GH_PATH = process.env.GITHUB_PATH || 'vscode-web-data.json', GH_BRANCH = process.env.GITHUB_BRANCH || '';
let ghSha = '', ghTimer = null, ghState = GH_TOKEN && GH_REPO ? 'idle' : 'off', ghErr = '';
const readFsDoc = () => { try { return JSON.parse(fs.readFileSync(FS_FILE, 'utf8')); } catch { return null; } };
function writeFsDoc(doc) {
  const old = readFsDoc();
  const tmp = FS_FILE + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(doc)); fs.renameSync(tmp, FS_FILE);
  try {
    if (old && old.fs.length > 2000 && doc.fs.length < old.fs.length * 0.5) fs.writeFileSync(path.join(VER_DIR, 'shrink-' + Date.now() + '.json'), JSON.stringify(old)); // 急に小さくなった時は直前を退避
    fs.writeFileSync(path.join(VER_DIR, new Date(doc.ts).toISOString().slice(0, 16).replace(/[:T]/g, '-') + '.json'), JSON.stringify(doc));
    const all = fs.readdirSync(VER_DIR).sort(); for (const f of all.slice(0, Math.max(0, all.length - 50))) fs.unlinkSync(path.join(VER_DIR, f));
  } catch {}
}
const ghUrl = (q = true) => `https://api.github.com/repos/${GH_REPO}/contents/${encodeURI(GH_PATH)}` + (q && GH_BRANCH ? `?ref=${encodeURIComponent(GH_BRANCH)}` : '');
const ghHead = (raw) => ({ Authorization: `Bearer ${GH_TOKEN}`, Accept: raw ? 'application/vnd.github.raw+json' : 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'vscode-web' });
async function ghPull() {
  const m = await fetch(ghUrl(), { headers: ghHead(false) });
  if (m.status === 404) return null; if (!m.ok) throw new Error('GitHub ' + m.status);
  ghSha = (await m.json()).sha;
  const r = await fetch(ghUrl(), { headers: ghHead(true) }); if (!r.ok) throw new Error('GitHub raw ' + r.status);
  return JSON.parse(await r.text());
}
async function ghPush(doc) {
  const body = { message: 'vscode-web autosave ' + new Date(doc.ts).toISOString(), content: Buffer.from(JSON.stringify(doc)).toString('base64'), ...(ghSha ? { sha: ghSha } : {}), ...(GH_BRANCH ? { branch: GH_BRANCH } : {}) };
  const r = await fetch(ghUrl(false), { method: 'PUT', headers: { ...ghHead(false), 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  if (r.status === 409 || r.status === 422) { await ghPull().catch(() => {}); throw new Error('conflict'); }
  if (!r.ok) throw new Error('GitHub ' + r.status);
  ghSha = (await r.json()).content.sha;
}
function ghSchedule() {
  if (ghState === 'off') return; clearTimeout(ghTimer); ghState = 'pending';
  ghTimer = setTimeout(async () => { const doc = readFsDoc(); if (!doc) return; for (let i = 0; i < 3; i++) { try { await ghPush(doc); ghState = 'ok'; ghErr = ''; return; } catch (e) { ghErr = e.message; } } ghState = 'error'; }, 15000);
}
const dataReady = (async () => { if (ghState === 'off' || readFsDoc()) return; try { const d = await ghPull(); if (d && typeof d.fs === 'string') { writeFsDoc(d); ghState = 'ok'; } } catch (e) { ghState = 'error'; ghErr = e.message; } })();
const J = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };
async function fsApi(req, res, p) {
  await dataReady;
  if (p === '/api/fs' && req.method === 'GET') return send(res, 200, JSON.stringify({ doc: readFsDoc(), cloud: ghState, err: ghErr }), J);
  if (p === '/api/fs' && req.method === 'PUT') {
    let b; try { b = JSON.parse((await readBody(req, 3e7)).toString()); } catch { return send(res, 400, '{"error":"bad json"}', J); }
    if (typeof b.fs !== 'string' || !(+b.ts > 0)) return send(res, 400, '{"error":"bad body"}', J);
    writeFsDoc({ fs: b.fs, ts: +b.ts }); ghSchedule(); return send(res, 200, JSON.stringify({ ok: true, cloud: ghState }), J);
  }
  if (p === '/api/fs/versions') return send(res, 200, JSON.stringify(fs.readdirSync(VER_DIR).sort().reverse()), J);
  const m = /^\/api\/fs\/versions\/([\w.-]+)$/.exec(p); if (m) { try { return send(res, 200, fs.readFileSync(path.join(VER_DIR, m[1])), J); } catch { return send(res, 404, '{}', J); } }
  return send(res, 404, '{}', J);
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  if (isSecure(req)) res.setHeader('Strict-Transport-Security', 'max-age=15552000');
  try {
    if (p === '/robots.txt') return send(res, 200, 'User-agent: *\nDisallow: /\n', { 'Content-Type': 'text/plain' });
    if (p === '/healthz') return send(res, 200, 'ok');
    if (p === '/login' && req.method === 'POST') {
      const ip = clientIp(req); const a = attempts.get(ip); const left = lockLeft(a);
      const html = { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' };
      if (left) return send(res, 429, LOGIN(`試行回数が多すぎます。${Math.ceil(left / 60e3)} 分後に再試行してください。`), { ...html, 'Retry-After': String(Math.ceil(left / 1000)) });
      const pw = new URLSearchParams((await readBody(req, 1e4)).toString()).get('password') || '';
      if (PASS && safeEq(pw, PASS)) { attempts.delete(ip); return send(res, 303, '', { Location: './', 'Set-Cookie': sessionCookie(req, makeToken(), SESSION_DAYS * 86400) }); }
      const f = recordFail(ip); await new Promise((r) => setTimeout(r, 400 + Math.min(f.n, 10) * 100));
      return send(res, 401, LOGIN(f.until > Date.now() ? `パスワードが違います。${Math.ceil((f.until - Date.now()) / 1000)} 秒ロックされました。` : `パスワードが違います (残り ${5 - f.n} 回)`), html);
    }
    if (p === '/logout') return send(res, 303, '', { Location: './login', 'Set-Cookie': sessionCookie(req, '', 0), 'Cache-Control': 'no-store' });
    if (!authed(req)) {
      if (p.startsWith('/api/')) return send(res, 401, JSON.stringify({ error: { message: 'unauthorized' } }), { 'Content-Type': 'application/json' });
      if (p === '/manifest.webmanifest' || p === '/icon.svg' || /^\/icon-\d+\.png$/.test(p)) return serveStatic(req, res, url);
      return send(res, 200, LOGIN(), { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    }
    if (p === '/login') return send(res, 303, '', { Location: './' });
    { const exp = tokenExp(cookies(req).vsw_session); if (exp && exp - Date.now() < (SESSION_DAYS - 7) * 864e5) res.setHeader('Set-Cookie', sessionCookie(req, makeToken(), SESSION_DAYS * 86400)); }
    if (p === '/api/ai/status') return send(res, 200, JSON.stringify({ configured: !!AI_KEY && (!!PASS || isLocal(req)), model: AI_MODEL, serverAuth: !!PASS, sessionDays: SESSION_DAYS }), { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    if (p === '/api/ai/chat/completions' && req.method === 'POST') return proxyAI(req, res);
    if (p === '/api/luau' && req.method === 'POST') return luauRun(req, res);
    if (p === '/api/luau/status') return send(res, 200, JSON.stringify({ luauAvailable: !!LUAU_BIN, bin: LUAU_BIN || null }), { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    if (p === '/api/fs' || p.startsWith('/api/fs/')) return fsApi(req, res, p);
    if (p.startsWith('/api/')) return send(res, 404, '{}');
    return serveStatic(req, res, url);
  } catch (e) { if (!res.headersSent) send(res, 500, 'error'); }
}).listen(PORT, HOST, () => {
  console.log(`vscode-web on http://${HOST}:${PORT}  root=${ROOT}`);
  if (PASS_GENERATED) console.log('\n' + '='.repeat(60) + `\n  ★ ログインパスワード: ${PASS}\n  (自動生成。再起動で変わる場合は Render の Environment に APP_PASSWORD を1回設定)\n` + '='.repeat(60) + '\n'); else console.log('  auth: APP_PASSWORD set (login required)');
  console.log(`  data: ${DATA_DIR}  github-sync: ${ghState === 'off' ? 'off (GITHUB_TOKEN / GITHUB_REPO を設定すると自動バックアップ)' : GH_REPO}`);
  warmup();
  console.log(`  AI: ${AI_KEY ? `proxy -> ${AI_BASE} (model ${AI_MODEL})` : 'no AI_API_KEY (AI disabled unless direct mode in UI)'}`);
});
