#!/usr/bin/env node
// vscode-web server: static files + private login + server-side AI proxy (no dependencies).
// Env: PORT (8787), HOST (0.0.0.0), APP_PASSWORD, AI_API_KEY, AI_BASE_URL (https://api.x.ai/v1), AI_MODEL (grok-4), AI_INLINE_MODEL, SESSION_SECRET
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const loadEnv = (f) => { try { for (const l of fs.readFileSync(f, 'utf8').split('\n')) { const m = /^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/.exec(l); if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, ''); } } catch {} };
loadEnv(path.join(__dirname, '.env'));
const PORT = +(process.env.PORT || 8787), HOST = process.env.HOST || '0.0.0.0';
const PASS = process.env.APP_PASSWORD || '';
const AI_KEY = process.env.AI_API_KEY || '';
const AI_BASE = (process.env.AI_BASE_URL || 'https://api.x.ai/v1').replace(/\/+$/, '');
const AI_MODEL = process.env.AI_MODEL || 'grok-4';
const SECRET = process.env.SESSION_SECRET || crypto.createHash('sha256').update('vsw:' + PASS + ':' + AI_KEY).digest('hex');
const ROOT = fs.existsSync(path.join(__dirname, 'dist')) ? path.join(__dirname, 'dist') : __dirname;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ttf': 'font/ttf', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8', '.ico': 'image/x-icon' };

const sign = (v) => crypto.createHmac('sha256', SECRET).update(v).digest('base64url');
const SESSION_DAYS = 180;
// token = exp.sig ; sig binds the expiry to the current password (changing APP_PASSWORD logs every device out)
const PW_TAG = crypto.createHash('sha256').update('pw:' + PASS).digest('hex').slice(0, 16);
const makeToken = () => { const exp = Date.now() + SESSION_DAYS * 864e5; return `${exp}.${sign(exp + '.' + PW_TAG)}`; };
const tokenExp = (t) => { if (!t) return 0; const [exp, sig] = t.split('.'); if (!exp || !sig || +exp < Date.now()) return 0; const want = sign(exp + '.' + PW_TAG); return sig.length === want.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(want)) ? +exp : 0; };
const validToken = (t) => tokenExp(t) > 0;
const isSecure = (req) => process.env.COOKIE_SECURE === '1' || req.headers['x-forwarded-proto'] === 'https' || !!req.headers['cf-visitor'] || !!req.socket.encrypted;
const sessionCookie = (req, v, maxAge) => `vsw_session=${v}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${isSecure(req) ? '; Secure' : ''}`;
// login rate limit: 5 free attempts, then exponential lockout (30s, 60s, 2m … max 60m)
// forwarded headers are only trusted when the request comes from a local reverse proxy / tunnel (otherwise they could be spoofed to dodge the lockout)
const clientIp = (req) => { const ra = req.socket.remoteAddress || ''; const local = ra === '127.0.0.1' || ra === '::1' || ra === '::ffff:127.0.0.1'; return local || process.env.TRUST_PROXY === '1' ? String(req.headers['cf-connecting-ip'] || (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || ra) : ra; };
function lockLeft(a) { return a && a.until > Date.now() ? a.until - Date.now() : 0; }
function recordFail(ip) { const a = attempts.get(ip) || { n: 0, until: 0, t: Date.now() }; a.n++; a.t = Date.now(); if (a.n >= 5) a.until = Date.now() + Math.min(60 * 60e3, 30e3 * 2 ** (a.n - 5)); attempts.set(ip, a); return a; }
setInterval(() => { const now = Date.now(); for (const [k, a] of attempts) if (now - a.t > 24 * 3600e3) attempts.delete(k); }, 3600e3).unref();
const safeEq = (a, b) => { const x = crypto.createHash('sha256').update(a).digest(), y = crypto.createHash('sha256').update(b).digest(); return crypto.timingSafeEqual(x, y); };
const cookies = (req) => Object.fromEntries((req.headers.cookie || '').split(';').map((c) => c.trim().split('=')).filter((x) => x[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join('='))]));
const isLocal = (req) => { const a = req.socket.remoteAddress || ''; return !req.headers['x-forwarded-for'] && !req.headers['cf-connecting-ip'] && (a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1'); };
function authed(req) {
  if (!PASS) return true;
  if (validToken(cookies(req).vsw_session)) return true;
  const h = req.headers.authorization || '';
  if (h.startsWith('Bearer ') && safeEq(h.slice(7), PASS)) return true;
  if (h.startsWith('Basic ')) { const [, p] = Buffer.from(h.slice(6), 'base64').toString().split(/:(.*)/s); if (p !== undefined && safeEq(p, PASS)) return true; }
  return false;
}
const SEC = { 'X-Robots-Tag': 'noindex, nofollow, noarchive', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY' };
const send = (res, code, body, headers = {}) => { res.writeHead(code, { ...SEC, ...headers }); res.end(body); };
const attempts = new Map();
const LOGIN = (err = '') => `<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><meta name="theme-color" content="#14161b"><title>vscode — ログイン</title>
<style>*{box-sizing:border-box}html,body{margin:0;height:100%;background:#14161b;color:#c9ced8;font:15px -apple-system,BlinkMacSystemFont,"Segoe UI","Hiragino Sans","Noto Sans JP",sans-serif;-webkit-text-size-adjust:100%}
body{display:flex;align-items:center;justify-content:center;background:radial-gradient(1200px 600px at 50% -10%,#1f3b5c55,transparent),#14161b}
form{width:min(360px,90vw);display:flex;flex-direction:column;gap:12px;padding:32px 28px;border-radius:16px;background:#1b1e25;border:1px solid #2a2f3a;box-shadow:0 20px 60px #0008}
.logo{display:flex;align-items:center;gap:10px;margin-bottom:6px}.logo svg{width:36px;height:36px}h1{font-size:20px;font-weight:600;color:#eef1f6;margin:0}p{margin:0 0 6px;color:#8a93a3;font-size:13px}
input,button{height:46px;border-radius:10px;font-size:16px;font-family:inherit}input{background:#12141a;color:#fff;border:1px solid #2f3542;padding:0 14px;outline:none;transition:border-color .15s,box-shadow .15s}input:focus{border-color:#3b8eea;box-shadow:0 0 0 3px #3b8eea33}
button{background:#3b8eea;color:#fff;border:0;cursor:pointer;font-weight:600}button:active{transform:translateY(1px)}.e{color:#f38b8b;min-height:18px;font-size:13px}.n{font-size:12px;color:#6c7586;text-align:center}</style></head>
<body><form method="post" action="./login"><div class="logo"><svg viewBox="0 0 16 16"><rect x="2.5" y="2.5" width="11" height="11" rx="2" transform="rotate(15 8 8)" fill="#3b8eea"/><rect x="6.5" y="6.5" width="3" height="3" transform="rotate(15 8 8)" fill="#fff"/></svg><h1>vscode</h1></div><p>Lua / Luau エディタ — プライベート</p><input type="password" name="password" placeholder="パスワード" autofocus autocomplete="current-password" enterkeyhint="go"><div class="e">${err}</div><button>ログイン</button><div class="n">この端末では ${SESSION_DAYS} 日間ログインしたままになります</div></form></body></html>`;

function readBody(req, limit = 2e6) { return new Promise((resolve, reject) => { let n = 0; const chunks = []; req.on('data', (c) => { n += c.length; if (n > limit) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); }); req.on('end', () => resolve(Buffer.concat(chunks))); req.on('error', reject); }); }

async function proxyAI(req, res) {
  if (!AI_KEY) return send(res, 503, JSON.stringify({ error: { message: 'サーバーに AI_API_KEY が設定されていません' } }), { 'Content-Type': 'application/json' });
  if (!PASS && !isLocal(req)) return send(res, 403, JSON.stringify({ error: { message: 'APP_PASSWORD 未設定のため、AI プロキシはローカルからのみ利用できます' } }), { 'Content-Type': 'application/json' });
  let body;
  try { body = JSON.parse((await readBody(req)).toString()); } catch { return send(res, 400, JSON.stringify({ error: { message: 'bad json' } }), { 'Content-Type': 'application/json' }); }
  const out = { model: body.model || AI_MODEL, messages: Array.isArray(body.messages) ? body.messages : [], stream: !!body.stream };
  for (const k of ['temperature', 'max_tokens', 'top_p', 'stop']) if (body[k] !== undefined) out[k] = body[k];
  const ac = new AbortController();
  res.on('close', () => { if (!res.writableFinished) ac.abort(); });
  try {
    const up = await fetch(AI_BASE + '/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${AI_KEY}` }, body: JSON.stringify(out), signal: ac.signal });
    res.writeHead(up.status, { ...SEC, 'Content-Type': up.headers.get('content-type') || 'application/json', 'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no' });
    if (!up.body) return res.end();
    for await (const chunk of up.body) res.write(chunk);
    res.end();
  } catch (e) {
    if (ac.signal.aborted) return;
    if (!res.headersSent) send(res, 502, JSON.stringify({ error: { message: 'upstream error: ' + e.message } }), { 'Content-Type': 'application/json' }); else res.end();
  }
}

function serveStatic(req, res, url) {
  let p = decodeURIComponent(url.pathname);
  if (p.endsWith('/')) p += 'index.html';
  let file = path.normalize(path.join(ROOT, p));
  if (!file.startsWith(ROOT)) return send(res, 403, 'forbidden');
  if (/(^|\/)(server\.js|\.env|package(-lock)?\.json)$/.test(p)) return send(res, 404, 'not found');
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(ROOT, 'index.html');
  const ext = path.extname(file);
  const headers = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': /\/assets\//.test(file) ? 'public, max-age=31536000, immutable' : 'no-cache' };
  const raw = fs.readFileSync(file);
  if (/gzip/.test(req.headers['accept-encoding'] || '') && /text|javascript|json|svg|css/.test(headers['Content-Type']) && raw.length > 1024) {
    return send(res, 200, zlib.gzipSync(raw, { level: 6 }), { ...headers, 'Content-Encoding': 'gzip', Vary: 'Accept-Encoding' });
  }
  send(res, 200, raw, headers);
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  try {
    if (p === '/robots.txt') return send(res, 200, 'User-agent: *\nDisallow: /\n', { 'Content-Type': 'text/plain' });
    if (p === '/healthz') return send(res, 200, 'ok');
    if (p === '/login' && req.method === 'POST') {
      const ip = clientIp(req); const a = attempts.get(ip); const left = lockLeft(a);
      const html = { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' };
      if (left) return send(res, 429, LOGIN(`試行回数が多すぎます。${Math.ceil(left / 60e3)} 分後に再試行してください。`), { ...html, 'Retry-After': String(Math.ceil(left / 1000)) });
      const pw = new URLSearchParams((await readBody(req, 1e4)).toString()).get('password') || '';
      if (PASS && safeEq(pw, PASS)) { attempts.delete(ip); return send(res, 303, '', { Location: './', 'Set-Cookie': sessionCookie(req, makeToken(), SESSION_DAYS * 86400) }); }
      const f = recordFail(ip); await new Promise((r) => setTimeout(r, 400 + Math.min(f.n, 10) * 100));
      return send(res, 401, LOGIN(f.until > Date.now() ? `パスワードが違います。${Math.ceil((f.until - Date.now()) / 1000)} 秒ロックされました。` : `パスワードが違います (残り ${5 - f.n} 回)`), html);
    }
    if (p === '/logout') return send(res, 303, '', { Location: './login', 'Set-Cookie': sessionCookie(req, '', 0), 'Cache-Control': 'no-store' });
    if (!authed(req)) {
      if (p.startsWith('/api/')) return send(res, 401, JSON.stringify({ error: { message: 'unauthorized' } }), { 'Content-Type': 'application/json' });
      if (p === '/manifest.webmanifest' || p === '/icon.svg' || /^\/icon-\d+\.png$/.test(p)) return serveStatic(req, res, url);
      return send(res, 200, LOGIN(), { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    }
    if (p === '/login') return send(res, 303, '', { Location: './' });
    { const exp = tokenExp(cookies(req).vsw_session); if (exp && exp - Date.now() < (SESSION_DAYS - 7) * 864e5) res.setHeader('Set-Cookie', sessionCookie(req, makeToken(), SESSION_DAYS * 86400)); }
    if (p === '/api/ai/status') return send(res, 200, JSON.stringify({ configured: !!AI_KEY && (!!PASS || isLocal(req)), model: AI_MODEL, serverAuth: !!PASS, sessionDays: SESSION_DAYS }), { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    if (p === '/api/ai/chat/completions' && req.method === 'POST') return proxyAI(req, res);
    if (p.startsWith('/api/')) return send(res, 404, '{}');
    return serveStatic(req, res, url);
  } catch (e) { if (!res.headersSent) send(res, 500, 'error'); }
}).listen(PORT, HOST, () => {
  console.log(`vscode-web on http://${HOST}:${PORT}  root=${ROOT}`);
  console.log(`  auth: ${PASS ? 'APP_PASSWORD set (login required)' : 'NONE (client-side lock only) — set APP_PASSWORD before exposing publicly!'}`);
  console.log(`  AI: ${AI_KEY ? `proxy -> ${AI_BASE} (model ${AI_MODEL})` : 'no AI_API_KEY (AI disabled unless direct mode in UI)'}`);
});
