import { basicSetup, EditorView } from 'codemirror';
import { autocompletion, acceptCompletion } from '@codemirror/autocomplete';
import { indentWithTab, undo, redo } from '@codemirror/commands';
import { Compartment, indentUnit, indentRange } from '@codemirror/language';
import { EditorState, StateEffect, StateField, Prec } from '@codemirror/state';
import { keymap, Decoration, WidgetType } from '@codemirror/view';
import { linter } from '@codemirror/lint';
import { searchKeymap } from '@codemirror/search';
import { lua } from '@fazelstudio/codemirror-lang-lua';
import { luau } from '@fazelstudio/codemirror-lang-luau';

const STORAGE_KEY = 'luaforge.workspace.v1';
const LSP_SETTINGS = {
  platform: { type: 'roblox' },
  analyzeLuaFiles: true,
  diagnostics: { strictDatamodelTypes: false, includeDependents: true, workspace: true },
  sourcemap: { enabled: false },
  completion: {
    autocompleteEnd: true,
    addParentheses: true,
    fillCallArguments: true,
    imports: { enabled: true, suggestServices: true, suggestRequires: true }
  },
  hover: { enabled: true, strictDatamodelTypes: false, multilineFunctionDefinitions: true },
  index: { enabled: true, maxFiles: 80 }
};
const STARTER = `--!strict
-- Welcome to LuaForge
-- Lua + Luau editor with Roblox Studio API completions.

local Players = game:GetService("Players")
local player = Players.LocalPlayer

local function greet(name: string): string
    return "Hello, " .. name
end

print(greet(player and player.Name or "developer"))
`;

const ROBLOX_GLOBALS = [
  'game','workspace','script','plugin','shared','_G','Enum','Instance','Vector2','Vector3','Vector2int16','Vector3int16',
  'CFrame','Color3','BrickColor','UDim','UDim2','Rect','Ray','RaycastParams','TweenInfo','NumberRange','NumberSequence',
  'ColorSequence','PhysicalProperties','Region3','Axes','Faces','Random','DateTime','os','task','math','string','table',
  'coroutine','utf8','bit32','buffer','debug','assert','error','getmetatable','ipairs','pairs','next','pcall','xpcall',
  'print','warn','require','select','tonumber','tostring','type','typeof','unpack','rawget','rawset','rawequal',
  'setmetatable','collectgarbage','gcinfo'
];
const LUA_KEYWORDS = ['and','break','continue','do','else','elseif','end','export','false','for','function','if','in','local','nil','not','or','repeat','return','then','true','type','until','while'];
const LUA_BUILTINS = ['print','warn','error','assert','type','typeof','tostring','tonumber','pairs','ipairs','next','select','unpack','pcall','xpcall','rawequal','rawget','rawset','setmetatable','getmetatable','require','math','string','table','coroutine','utf8','bit32','buffer','task','os','debug'];
const ROBLOX_APIS = [
  ['game:GetService("Players")','GetService · DataModel','function'],
  ['game:GetService("ReplicatedStorage")','GetService · DataModel','function'],
  ['game:GetService("Workspace")','GetService · DataModel','function'],
  ['game:GetService("RunService")','GetService · DataModel','function'],
  ['game:GetService("TweenService")','GetService · DataModel','function'],
  ['game:GetService("UserInputService")','GetService · DataModel','function'],
  ['game:GetService("CollectionService")','GetService · DataModel','function'],
  ['game:GetService("ContextActionService")','GetService · DataModel','function'],
  ['game:GetService("HttpService")','GetService · DataModel','function'],
  ['game:GetService("Lighting")','GetService · DataModel','function'],
  ['game:GetService("SoundService")','GetService · DataModel','function'],
  ['game:GetService("StarterGui")','GetService · DataModel','function'],
  ['game:GetService("MarketplaceService")','GetService · DataModel','function'],
  ['game:GetService("PathfindingService")','GetService · DataModel','function'],
  ['game:GetService("Debris")','GetService · DataModel','function'],
  ['Players.LocalPlayer','Player','property'],['Players:GetPlayers()','Player[]','method'],['Players.PlayerAdded','RBXScriptSignal','event'],
  ['workspace.CurrentCamera','Camera','property'],['workspace:Raycast()','RaycastResult?','method'],
  ['Instance.new("Part")','Instance','function'],['Vector3.new(0, 0, 0)','Vector3','function'],
  ['Vector2.new(0, 0)','Vector2','function'],['CFrame.new()','CFrame','function'],['Color3.fromRGB(255, 255, 255)','Color3','function'],
  ['UDim2.fromScale(1, 1)','UDim2','function'],['TweenInfo.new(0.5)','TweenInfo','function'],
  ['task.wait()','yield · task','function'],['task.spawn(function()\n\t\nend)','thread · task','snippet'],
  ['task.defer(function()\n\t\nend)','thread · task','snippet'],['RunService.Heartbeat','RBXScriptSignal','event'],
  ['RunService.RenderStepped','RBXScriptSignal','event'],['TweenService:Create()','Tween','method'],
  ['UserInputService.InputBegan','RBXScriptSignal','event'],['CollectionService:GetTagged("Tag")','Instance[]','method'],
  ['HttpService:JSONEncode()','string','method'],['HttpService:JSONDecode()','any','method'],
  ['Enum.EasingStyle.Quad','EnumItem','enum'],['Enum.EasingDirection.Out','EnumItem','enum'],
  ['Enum.UserInputType.MouseButton1','EnumItem','enum'],['Enum.KeyCode.E','EnumItem','enum']
];

const snippets = [
  { label: 'function', detail: 'Function block', apply: 'function name()\n\t\nend', type: 'snippet' },
  { label: 'local function', detail: 'Local function block', apply: 'local function name()\n\t\nend', type: 'snippet' },
  { label: 'if', detail: 'If block', apply: 'if condition then\n\t\nend', type: 'snippet' },
  { label: 'ifelse', detail: 'If / else block', apply: 'if condition then\n\t\nelse\n\t\nend', type: 'snippet' },
  { label: 'fori', detail: 'Numeric for loop', apply: 'for i = 1, 10 do\n\t\nend', type: 'snippet' },
  { label: 'forp', detail: 'Generic for loop', apply: 'for key, value in pairs(table) do\n\t\nend', type: 'snippet' },
  { label: 'while', detail: 'While loop', apply: 'while condition do\n\t\nend', type: 'snippet' },
  { label: 'pcall', detail: 'Protected call', apply: 'local success, result = pcall(function()\n\t\nend)', type: 'snippet' },
  { label: 'service', detail: 'Roblox GetService', apply: 'local Service = game:GetService("ServiceName")', type: 'snippet' },
  { label: 'connect', detail: 'Connect event', apply: 'Event:Connect(function()\n\t\nend)', type: 'snippet' },
  { label: 'strict', detail: 'Luau strict directive', apply: '--!strict', type: 'snippet' },
  { label: 'type', detail: 'Type alias', apply: 'type Name = {\n\t\n}', type: 'snippet' }
];

let docs = [];
let activeId = null;
let editor = null;
let fileHandle = null;
let autosaveTimer = null;
let aiTimer = null;
let aiController = null;
let aiEnabled = false;
let ghostEnabled = true;
let wrapEnabled = true;
let isLight = false;
let lastDocChange = 0;
let toastTimer = null;
let lspSocket = null;
let lspReady = false;
let lspRootUri = '';
let lspUris = new Map();
let lspPending = new Map();
let lspRequestId = 0;
let lspVersion = new Map();
let lspDiagnosticsByUri = new Map();
let lspInitTimer = null;
let lspDebounceTimer = null;
let lspGhostTimer = null;
let lspGhostSequence = 0;
let editorFontSize = 14;
try { editorFontSize = Math.max(11, Math.min(22, Number(localStorage.getItem('luaforge.fontSize')) || 14)); } catch { /* use default */ }
let platformStatus = { lspEnabled: false, apiDbReady: false, apiClasses: 0, apiEnums: 0, apiDbVersion: '' };
let apiServiceNames = null;
const apiCompletionCache = new Map();
const languageCompartment = new Compartment();
const themeCompartment = new Compartment();
const wrapCompartment = new Compartment();
const diagnosticsEffect = StateEffect.define();
const diagnosticsField = StateField.define({
  create: () => [],
  update(value, tr) {
    let next = value.map(item => ({ ...item, from: tr.changes.mapPos(item.from), to: tr.changes.mapPos(item.to) }));
    for (const effect of tr.effects) if (effect.is(diagnosticsEffect)) next = effect.value;
    return next;
  }
});

function id() { return `f_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`; }
function activeDoc() { return docs.find(d => d.id === activeId); }
function extForLanguage(language) { return language === 'lua' ? lua() : luau(); }
function themeExtension(light) {
  return EditorView.theme(light ? {
    '&': { backgroundColor: '#f7f8fc', color: '#243246', fontSize: `${editorFontSize}px` },
    '.cm-gutters': { backgroundColor: '#f0f2f8', color: '#8491a4' },
    '.cm-activeLine': { backgroundColor: '#e9edfa' },
    '.cm-activeLineGutter': { backgroundColor: '#e5e9f7', color: '#6256bb' },
    '.cm-cursor': { borderLeftColor: '#6559c9' },
    '.cm-selectionBackground': { background: '#bdb5ff88' },
    '&.cm-focused .cm-selectionBackground': { background: '#bdb5ff99' }
  } : {
    '&': { backgroundColor: '#0c111a', color: '#d8e1ec', fontSize: `${editorFontSize}px` },
    '.cm-gutters': { backgroundColor: '#0c111a', color: '#445267' },
    '.cm-activeLine': { backgroundColor: '#111a28' },
    '.cm-activeLineGutter': { backgroundColor: '#171a2c', color: '#a99cff' },
    '.cm-cursor': { borderLeftColor: '#b7aaff' },
    '.cm-selectionBackground': { background: '#5547ac66' },
    '&.cm-focused .cm-selectionBackground': { background: '#5547ac88' }
  }, { dark: !light });
}

class GhostWidget extends WidgetType {
  constructor(text) { super(); this.text = text; }
  toDOM() {
    const span = document.createElement('span');
    span.className = 'cm-inline-ghost';
    span.setAttribute('aria-hidden', 'true');
    span.textContent = this.text;
    return span;
  }
  ignoreEvent() { return true; }
  eq(other) { return other.text === this.text; }
}
const setGhostEffect = StateEffect.define();
const clearGhostEffect = StateEffect.define();
const ghostField = StateField.define({
  create: () => ({ text: '', pos: -1, decorations: Decoration.none }),
  update(value, tr) {
    let next = value;
    for (const effect of tr.effects) {
      if (effect.is(clearGhostEffect)) next = { text: '', pos: -1, decorations: Decoration.none };
      if (effect.is(setGhostEffect)) {
        const { text, pos } = effect.value;
        const deco = Decoration.set([Decoration.widget({ widget: new GhostWidget(text), side: 1 }).range(pos)]);
        next = { text, pos, decorations: deco };
      }
    }
    if (tr.docChanged || tr.selectionSet) next = { text: '', pos: -1, decorations: Decoration.none };
    return next;
  },
  provide: field => EditorView.decorations.from(field, value => value.decorations)
});
function acceptGhost(view) {
  const ghost = view.state.field(ghostField);
  if (!ghost.text || ghost.pos !== view.state.selection.main.head) return false;
  view.dispatch({ changes: { from: ghost.pos, to: ghost.pos, insert: ghost.text }, effects: clearGhostEffect.of(null) });
  return true;
}
function clearGhost(view = editor) { if (view) view.dispatch({ effects: clearGhostEffect.of(null) }); }

function localContextCompletions(context) {
  const word = context.matchBefore(/[\w.:'"]*/);
  if (!word || (word.from === word.to && !context.explicit)) return null;
  const textBefore = context.state.doc.sliceString(Math.max(0, context.pos - 220), context.pos);
  let options = [];
  const serviceMatch = textBefore.match(/GetService\(["']([^"']*)$/);
  if (serviceMatch) {
    const services = apiServiceNames || ['Players','ReplicatedStorage','ServerStorage','ServerScriptService','Workspace','RunService','TweenService','UserInputService','ContextActionService','CollectionService','HttpService','Lighting','SoundService','StarterGui','StarterPlayer','MarketplaceService','PathfindingService','Debris','Teams','TextService','GuiService','ContentProvider','DataStoreService','MessagingService','MemoryStoreService','TeleportService','BadgeService','ProximityPromptService','PhysicsService','PolicyService','LocalizationService','Chat','VoiceChatService'];
    options = services.map(label => ({ label, type: 'class', detail: 'Roblox service', apply: `${label}")` }));
  } else {
    options = [
      ...LUA_KEYWORDS.map(label => ({ label, type: 'keyword', detail: 'Luau keyword' })),
      ...LUA_BUILTINS.map(label => ({ label, type: 'function', detail: 'Lua / Luau standard library' })),
      ...ROBLOX_GLOBALS.map(label => ({ label, type: 'variable', detail: 'Luau / Roblox global' })),
      ...ROBLOX_APIS.map(([label, detail, type]) => ({ label, detail, type: type === 'snippet' ? 'text' : type, apply: label })),
      ...snippets.map(item => ({ ...item, apply: item.apply }))
    ];
  }
  const query = word.text.toLowerCase();
  const filtered = options.filter(option => !query || option.label.toLowerCase().includes(query.slice(-Math.min(query.length, 42))));
  if (!filtered.length && !context.explicit) return null;
  return { from: word.from, options: filtered.slice(0, 45), validFor: /^[\w.:'"]*$/ };
}

function inferApiClass(before, receiver) {
  if (!receiver) return '';
  const escaped = receiver.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const service = before.match(new RegExp(`(?:local|const)\\s+${escaped}\\s*[:=]\\s*game:GetService\\(["']([A-Za-z0-9_]+)["']\\)`));
  if (service) return service[1];
  const instance = before.match(new RegExp(`(?:local|const)\\s+${escaped}\\s*[:=]\\s*Instance\\.new\\(["']([A-Za-z0-9_]+)["']\\)`));
  if (instance) return instance[1];
  const typed = before.match(new RegExp(`(?:local|const)\\s+${escaped}\\s*:\\s*([A-Za-z0-9_]+)`));
  if (typed) return typed[1];
  if (receiver === 'workspace') return 'Workspace';
  if (receiver === 'game') return 'DataModel';
  return '';
}

async function fetchApiCompletionData(params) {
  const key = params.toString();
  if (apiCompletionCache.has(key)) return apiCompletionCache.get(key);
  const response = await fetch(`/api/roblox-api?${key}`);
  if (!response.ok) throw new Error('API search unavailable');
  const data = await response.json();
  apiCompletionCache.set(key, data);
  if (apiCompletionCache.size > 160) apiCompletionCache.delete(apiCompletionCache.keys().next().value);
  return data;
}

async function apiCompletionSource(context) {
  if (!platformStatus.apiDbReady) return null;
  const word = context.matchBefore(/[A-Za-z_][\w.]*/);
  if (!word || (word.from === word.to && !context.explicit)) return null;
  const before = context.state.doc.sliceString(0, context.pos);
  const parts = word.text.split('.');
  const receiver = parts.length > 1 ? parts.slice(0, -1).join('.') : '';
  const query = parts.at(-1) || '';
  const className = inferApiClass(before, receiver);
  if (!query && !context.explicit) return null;
  const params = new URLSearchParams({ q: query, limit: '35' });
  if (className) params.set('class', className);
  try {
    const payload = await fetchApiCompletionData(params);
    const items = (payload.results || []).map(item => {
      if (item.kind === 'member') {
        const type = item.memberKind === 'Function' ? 'function' : item.memberKind === 'Event' ? 'event' : item.memberKind === 'Property' ? 'property' : 'variable';
        return { label: item.name, type, detail: `${item.className} · ${item.signature}`, apply: item.memberKind === 'Function' ? `${item.name}(` : item.name, boost: 8 };
      }
      if (item.kind === 'class') return { label: item.name, type: 'class', detail: item.detail, boost: 6 };
      return { label: item.name, type: 'enum', detail: `Enum · ${(item.items || []).slice(0, 5).join(', ')}`, boost: 4 };
    });
    if (receiver && className) return { from: word.from + word.text.lastIndexOf('.') + 1, options: items, validFor: /^[\w]*$/ };
    return { from: word.from, options: items, validFor: /^[\w.]*$/ };
  } catch { return null; }
}

async function lspCompletionSource(context) {
  if (!lspReady || !lspCurrentUri()) return null;
  const word = context.matchBefore(/[A-Za-z_][\w.]*/);
  if (!word || (word.from === word.to && !context.explicit)) return null;
  const uri = lspCurrentUri();
  const pos = toLspPosition(context.state.doc, context.pos);
  try {
    const result = await lspRequest('textDocument/completion', { textDocument: { uri }, position: pos, context: { triggerKind: context.explicit ? 1 : 2 } }, 1600);
    const raw = Array.isArray(result) ? result : result?.items || [];
    const options = raw.slice(0, 80).map(item => {
      const detail = typeof item.documentation === 'string' ? item.documentation : item.documentation?.value || item.detail || '';
      const insertText = plainSnippet(item.textEdit?.newText || item.insertText || item.label);
      return {
        label: item.label,
        detail: String(detail).slice(0, 180),
        type: completionKind(item.kind),
        boost: 16,
        apply(view, _completion, from, to) {
          const editFrom = item.textEdit?.range ? fromLspPosition(view.state.doc, item.textEdit.range.start) : from;
          const editTo = item.textEdit?.range ? fromLspPosition(view.state.doc, item.textEdit.range.end) : to;
          view.dispatch({
            changes: { from: editFrom, to: Math.max(editFrom, editTo), insert: insertText },
            selection: { anchor: editFrom + insertText.length },
            scrollIntoView: true
          });
        }
      };
    });
    if (!options.length) return null;
    return { from: word.from, options, validFor: /^[\w.]*$/ };
  } catch { return null; }
}

function completionKind(kind) {
  return ({ 2: 'method', 3: 'function', 4: 'function', 5: 'variable', 6: 'variable', 7: 'class', 8: 'interface', 9: 'module', 10: 'property', 13: 'enum', 14: 'keyword', 15: 'snippet', 21: 'constant' })[kind] || 'text';
}

function lspCurrentUri() { return lspUris.get(activeId) || ''; }
function lspSend(message) {
  if (lspSocket?.readyState === WebSocket.OPEN) lspSocket.send(JSON.stringify({ jsonrpc: '2.0', ...message }));
}
function lspNotify(method, params = {}) { lspSend({ method, params }); }
function lspRequest(method, params = {}, timeoutMs = 2500) {
  if (!lspReady && method !== 'initialize') return Promise.reject(new Error('LSP is not ready'));
  const requestId = ++lspRequestId;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { lspPending.delete(requestId); reject(new Error('LSP request timed out')); }, timeoutMs);
    lspPending.set(requestId, { resolve, reject, timer });
    lspSend({ id: requestId, method, params });
  });
}
function toLspPosition(doc, offset) {
  const line = doc.lineAt(Math.max(0, Math.min(offset, doc.length)));
  return { line: line.number - 1, character: offset - line.from };
}
function fromLspPosition(doc, position) {
  const lineNumber = Math.max(1, Math.min(doc.lines, Number(position?.line || 0) + 1));
  const line = doc.line(lineNumber);
  return Math.max(line.from, Math.min(line.to, line.from + Number(position?.character || 0)));
}
function lspWsUrl() { return `${location.protocol === 'https:' ? 'wss:' : 'ws:'}//${location.host}/lsp`; }
async function startLsp() {
  try {
    lspSocket = new WebSocket(lspWsUrl());
  } catch { setLspBadge(false, 'LSP unavailable'); return; }
  lspSocket.addEventListener('open', () => {
    const workspaceDocs = [];
    let totalBytes = 0;
    for (const doc of docs.slice(0, 80)) {
      const size = new TextEncoder().encode(doc.text || '').length;
      if (totalBytes + size > 4_800_000) continue;
      totalBytes += size;
      workspaceDocs.push({ id: doc.id, name: doc.name, text: doc.text, language: doc.language });
    }
    if (workspaceDocs.length < docs.length) showToast('LSP解析は最大80ファイル・約4.8MBまでです。エディタと端末内保存は継続します。');
    lspSocket.send(JSON.stringify({ type: 'workspace', docs: workspaceDocs }));
  }, { once: true });
  lspSocket.addEventListener('message', event => {
    let packet;
    try { packet = JSON.parse(event.data); } catch { return; }
    if (packet.type === 'ready') { initializeLsp(packet); return; }
    if (packet.type === 'fileAdded') {
      lspUris.set(packet.id, packet.uri);
      const doc = docs.find(item => item.id === packet.id);
      if (doc) openLspDocument(doc);
      return;
    }
    if (packet.type === 'error') { setLspBadge(false, 'LSP unavailable'); return; }
    if (packet.type === 'serverExit') { lspReady = false; setLspBadge(false, 'LSP stopped'); return; }
    handleLspPacket(packet);
  });
  lspSocket.addEventListener('close', () => { lspReady = false; setLspBadge(false, 'LSP disconnected'); });
  lspSocket.addEventListener('error', () => { lspReady = false; setLspBadge(false, 'Offline mode'); });
  lspInitTimer = setTimeout(() => { if (!lspReady) setLspBadge(false, 'Offline suggest'); }, 9000);
}
async function initializeLsp(packet) {
  lspRootUri = packet.rootUri || '';
  for (const file of packet.files || []) if (file.id) lspUris.set(file.id, file.uri);
  const capabilities = {
    workspace: { workspaceFolders: true, configuration: true, symbol: { dynamicRegistration: false } },
    textDocument: {
      synchronization: { dynamicRegistration: false, didSave: true },
      completion: { dynamicRegistration: false, completionItem: { snippetSupport: true, documentationFormat: ['markdown', 'plaintext'], resolveSupport: { properties: ['documentation', 'detail'] } } },
      hover: { dynamicRegistration: false, contentFormat: ['markdown', 'plaintext'] },
      signatureHelp: { dynamicRegistration: false, signatureInformation: { documentationFormat: ['markdown', 'plaintext'], parameterInformation: { labelOffsetSupport: true } } },
      publishDiagnostics: { relatedInformation: true, tagSupport: { valueSet: [1, 2] } },
      definition: { dynamicRegistration: false }, references: { dynamicRegistration: false },
      documentSymbol: { dynamicRegistration: false }, formatting: { dynamicRegistration: false }
    }
  };
  try {
    await lspRequest('initialize', {
      processId: null,
      clientInfo: { name: 'LuaForge Mobile', version: '3.0.0' },
      rootUri: lspRootUri,
      workspaceFolders: [{ uri: lspRootUri, name: 'LuaForge Workspace' }],
      capabilities,
      initializationOptions: { settings: { 'luau-lsp': LSP_SETTINGS } }
    }, 12000);
    lspNotify('initialized', {});
    lspNotify('workspace/didChangeConfiguration', { settings: { 'luau-lsp': LSP_SETTINGS } });
    lspReady = true;
    clearTimeout(lspInitTimer);
    for (const doc of docs) openLspDocument(doc);
    setLspBadge(true, 'Luau LSP ready');
  } catch (error) {
    lspReady = false;
    setLspBadge(false, 'Offline suggest');
  }
}
function openLspDocument(doc) {
  const uri = lspUris.get(doc.id);
  if (!uri || !lspReady) return;
  if (lspVersion.has(doc.id)) return;
  lspVersion.set(doc.id, 1);
  lspNotify('textDocument/didOpen', { textDocument: { uri, languageId: doc.language === 'lua' ? 'lua' : 'luau', version: 1, text: doc.text || '' } });
  if (doc.id === activeId) updateDiagnosticCount();
}
function ensureLspDocument(doc) {
  if (!lspReady || !doc || lspUris.has(doc.id)) return;
  if (lspSocket?.readyState === WebSocket.OPEN) lspSocket.send(JSON.stringify({ type: 'addFile', id: doc.id, name: doc.name, text: doc.text || '' }));
}
function switchLspDocument(doc) {
  if (!doc) return;
  if (!lspUris.has(doc.id)) ensureLspDocument(doc);
  else openLspDocument(doc);
  updateDiagnosticCount();
}
function scheduleLspChange() {
  if (!lspReady || !editor) return;
  clearTimeout(lspDebounceTimer);
  lspDebounceTimer = setTimeout(() => {
    const doc = activeDoc();
    const uri = lspCurrentUri();
    if (!doc || !uri) return;
    const version = (lspVersion.get(doc.id) || 1) + 1;
    lspVersion.set(doc.id, version);
    const text = editor.state.doc.toString();
    if (lspSocket?.readyState === WebSocket.OPEN) lspSocket.send(JSON.stringify({ type: 'writeFile', uri, text }));
    lspNotify('textDocument/didChange', { textDocument: { uri, version }, contentChanges: [{ text }] });
  }, 120);
}
function handleLspPacket(packet) {
  if (Object.hasOwn(packet, 'id') && packet.method) {
    const params = packet.params || {};
    if (packet.method === 'workspace/configuration') {
      const result = (params.items || []).map(item => {
        const section = String(item.section || '').replace(/^luau-lsp\.?/, '');
        if (!section) return LSP_SETTINGS;
        return section.split('.').reduce((value, key) => value && value[key], LSP_SETTINGS) ?? null;
      });
      lspSend({ id: packet.id, result });
    } else if (packet.method === 'workspace/workspaceFolders') {
      lspSend({ id: packet.id, result: lspRootUri ? [{ uri: lspRootUri, name: 'LuaForge Workspace' }] : [] });
    } else if (['window/workDoneProgress/create', 'client/registerCapability', 'workspace/inlayHint/refresh', 'workspace/semanticTokens/refresh', 'workspace/codeLens/refresh'].includes(packet.method)) {
      lspSend({ id: packet.id, result: null });
    } else if (packet.method === 'workspace/applyEdit') {
      lspSend({ id: packet.id, result: { applied: false, failureReason: 'Workspace edits are not applied automatically in the browser editor.' } });
    } else {
      lspSend({ id: packet.id, error: { code: -32601, message: `Unsupported client request: ${packet.method}` } });
    }
    return;
  }
  if (Object.hasOwn(packet, 'id') && !packet.method) {
    const pending = lspPending.get(packet.id);
    if (!pending) return;
    clearTimeout(pending.timer);
    lspPending.delete(packet.id);
    if (packet.error) pending.reject(new Error(packet.error.message || 'LSP error'));
    else pending.resolve(packet.result);
    return;
  }
  if (packet.method === 'textDocument/publishDiagnostics') {
    const uri = packet.params?.uri;
    lspDiagnosticsByUri.set(uri, packet.params?.diagnostics || []);
    if (uri === lspCurrentUri()) applyActiveDiagnostics(uri);
  }
}
function applyActiveDiagnostics(uri) {
  if (!editor) return;
  const diagnostics = (lspDiagnosticsByUri.get(uri) || []).map(item => {
    const from = fromLspPosition(editor.state.doc, item.range?.start || {});
    const to = fromLspPosition(editor.state.doc, item.range?.end || item.range?.start || {});
    const severity = ({ 1: 'error', 2: 'warning', 3: 'info', 4: 'info' })[item.severity] || 'warning';
    return { from, to: Math.max(from, to), severity, message: item.message || 'Luau diagnostic', source: item.source || 'Luau LSP' };
  });
  editor.dispatch({ effects: diagnosticsEffect.of(diagnostics) });
  updateDiagnosticCount();
}
function localSyntaxDiagnostics(state) {
  const text = state.doc.toString();
  const diagnostics = [];
  const stack = [];
  let quote = '';
  let quoteStart = -1;
  let escaped = false;
  let lineComment = false;
  let longClose = '';
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const next = text[i + 1];
    if (longClose) {
      if (text.startsWith(longClose, i)) { i += longClose.length - 1; longClose = ''; }
      continue;
    }
    if (lineComment) { if (char === '\n') lineComment = false; continue; }
    if (quote) {
      if (escaped) { escaped = false; continue; }
      if (char === '\\') { escaped = true; continue; }
      if (char === quote) { quote = ''; quoteStart = -1; }
      continue;
    }
    if (char === '-' && next === '-') {
      const longComment = text.slice(i + 2).match(/^\[(=*)\[/);
      if (longComment) {
        longClose = `]${longComment[1]}]`;
        i += 2 + longComment[0].length - 1;
      } else { lineComment = true; i++; }
      continue;
    }
    if (char === '[') {
      const longString = text.slice(i).match(/^\[(=*)\[/);
      if (longString) { longClose = `]${longString[1]}]`; i += longString[0].length - 1; continue; }
    }
    if (char === '"' || char === "'") { quote = char; quoteStart = i; continue; }
    if (char === '(' || char === '[' || char === '{') stack.push({ char, pos: i });
    else if (char === ')' || char === ']' || char === '}') {
      const expected = ({ ')': '(', ']': '[', '}': '{' })[char];
      const open = stack.pop();
      if (!open || open.char !== expected) diagnostics.push({ from: i, to: i + 1, severity: 'error', message: `対応する開始記号がありません: ${char}`, source: 'LuaForge' });
    }
  }
  for (const item of stack.slice(-5)) diagnostics.push({ from: item.pos, to: item.pos + 1, severity: 'error', message: `閉じられていない記号: ${item.char}`, source: 'LuaForge' });
  if (quote && quoteStart >= 0) diagnostics.push({ from: quoteStart, to: Math.min(text.length, quoteStart + 1), severity: 'error', message: '文字列が閉じられていません。', source: 'LuaForge' });
  return diagnostics;
}

function updateDiagnosticCount() {
  if (!editor) return;
  const server = lspDiagnosticsByUri.get(lspCurrentUri()) || [];
  const local = localSyntaxDiagnostics(editor.state);
  const total = server.length + local.length;
  const count = document.getElementById('diagnosticCount');
  if (count) count.textContent = String(total);
}
function updateModeBadge() {
  const pill = document.getElementById('aiStatus');
  if (!pill) return;
  const label = aiEnabled ? (lspReady ? 'AI + LSP' : 'AI + Local') : (lspReady ? 'LSP + Local' : 'Local suggest');
  pill.classList.toggle('enabled', aiEnabled || lspReady);
  pill.querySelector('span').textContent = label;
  const setting = document.getElementById('aiSettingValue');
  if (setting) setting.textContent = aiEnabled ? 'AI + Local + LSP' : (lspReady ? 'Local + LSP' : 'Local');
}
function setLspBadge(ready, label) {
  const mini = document.getElementById('lspStatusMini');
  if (mini) mini.textContent = label;
  const statusText = document.getElementById('lspStatusText');
  if (statusText) statusText.textContent = label;
  updateModeBadge();
}
async function loadApiServiceNames() {
  if (apiServiceNames) return;
  try {
    const response = await fetch('/api/roblox-api');
    if (response.ok) {
      const data = await response.json();
      apiServiceNames = Array.isArray(data.services) && data.services.length ? data.services : null;
    }
  } catch { /* keep the offline list */ }
}
async function jumpToDefinition() {
  if (!editor || !lspReady || !lspCurrentUri()) return showToast('定義ジャンプはLuau LSP接続後に使えます。');
  const pos = editor.state.selection.main.head;
  try {
    const result = await lspRequest('textDocument/definition', { textDocument: { uri: lspCurrentUri() }, position: toLspPosition(editor.state.doc, pos) });
    const location = Array.isArray(result) ? result[0] : result;
    const uri = location?.uri || location?.targetUri;
    const range = location?.range || location?.targetSelectionRange || location?.targetRange;
    if (!uri || !range?.start) return showToast('定義が見つかりませんでした。');
    const target = [...lspUris.entries()].find(([, value]) => value === uri)?.[0];
    if (target) {
      if (target !== activeId) switchDoc(target);
      const offset = fromLspPosition(editor.state.doc, range.start);
      editor.dispatch({ selection: { anchor: offset }, scrollIntoView: true });
      editor.focus();
      return;
    }
    const previewResponse = await fetch(`/api/definition-source?${new URLSearchParams({ uri, line: String(range.start.line || 0) })}`);
    if (!previewResponse.ok) return showToast('この定義は外部の標準型ファイルにあります。');
    const preview = await previewResponse.json();
    const body = document.getElementById('modalBody');
    body.innerHTML = `<p>${preview.name} · ${preview.selectedLine}行目</p><div class="definition-preview" id="definitionPreview"></div>`;
    const holder = body.querySelector('#definitionPreview');
    preview.lines.forEach((line, index) => {
      const row = document.createElement('div');
      row.className = `definition-line${preview.startLine + index === preview.selectedLine ? ' selected' : ''}`;
      const number = document.createElement('span'); number.textContent = String(preview.startLine + index);
      const code = document.createElement('code'); code.textContent = line;
      row.append(number, code); holder.append(row);
    });
    document.getElementById('modalTitle').textContent = '標準APIの定義';
    showModal();
  } catch { showToast('定義ジャンプに失敗しました。'); }
}

function hoverText(contents) {
  if (typeof contents === 'string') return contents;
  if (Array.isArray(contents)) return contents.map(item => typeof item === 'string' ? item : item?.value || '').filter(Boolean).join('\n\n');
  if (contents && typeof contents === 'object') return contents.value || contents.language && contents.value || '';
  return '';
}

async function requestHover() {
  if (!lspReady || !lspCurrentUri()) return showToast('型情報にはLuau LSP接続が必要です。');
  try {
    const result = await lspRequest('textDocument/hover', { textDocument: { uri: lspCurrentUri() }, position: toLspPosition(editor.state.doc, editor.state.selection.main.head) });
    const content = hoverText(result?.contents);
    if (!content) return showToast('この位置に表示できる型情報はありません。');
    const body = document.getElementById('modalBody');
    body.innerHTML = '';
    const pre = document.createElement('pre'); pre.className = 'definition-preview'; pre.textContent = content;
    body.append(pre); document.getElementById('modalTitle').textContent = '型・ドキュメント情報'; showModal();
  } catch { showToast('型情報を取得できませんでした。'); }
}

async function findReferences() {
  if (!lspReady || !lspCurrentUri()) return showToast('参照検索にはLuau LSP接続が必要です。');
  try {
    const result = await lspRequest('textDocument/references', {
      textDocument: { uri: lspCurrentUri() },
      position: toLspPosition(editor.state.doc, editor.state.selection.main.head),
      context: { includeDeclaration: true }
    }, 5000);
    const body = document.getElementById('modalBody'); body.innerHTML = '';
    const title = document.createElement('p'); title.textContent = `${(result || []).length} 件の参照`; body.append(title);
    for (const item of (result || []).slice(0, 120)) {
      const row = document.createElement('button'); row.className = 'api-result';
      const targetId = [...lspUris.entries()].find(([, uri]) => uri === item.uri)?.[0];
      const targetDoc = docs.find(doc => doc.id === targetId);
      const line = Number(item.range?.start?.line || 0) + 1;
      const name = document.createElement('strong'); name.textContent = targetDoc ? `${targetDoc.name}:${line}` : `${decodeURIComponent((item.uri || '').split('/').at(-1) || 'external')}:${line}`;
      const excerpt = document.createElement('small');
      if (targetDoc) excerpt.textContent = targetDoc.text.split(/\r?\n/)[line - 1]?.trim() || '(empty line)';
      else excerpt.textContent = '外部定義';
      row.append(name, excerpt);
      if (targetDoc) row.addEventListener('click', () => {
        closeModal(); if (activeId !== targetId) switchDoc(targetId);
        const offset = fromLspPosition(editor.state.doc, item.range.start);
        editor.dispatch({ selection: { anchor: offset }, scrollIntoView: true }); editor.focus();
      });
      body.append(row);
    }
    if (!result?.length) title.textContent = '参照は見つかりませんでした。';
    document.getElementById('modalTitle').textContent = '参照を検索'; showModal();
  } catch { showToast('参照検索に失敗しました。'); }
}

async function requestSignatureHelp() {
  if (!lspReady || !lspCurrentUri()) return showToast('署名ヘルプはLuau LSP接続後に使えます。');
  try {
    const result = await lspRequest('textDocument/signatureHelp', { textDocument: { uri: lspCurrentUri() }, position: toLspPosition(editor.state.doc, editor.state.selection.main.head) });
    const signature = result?.signatures?.[result.activeSignature || 0];
    if (signature) showToast(`${signature.label}${signature.documentation ? ` — ${String(signature.documentation.value || signature.documentation).slice(0, 90)}` : ''}`);
    else showToast('引数情報はありません。');
  } catch { showToast('署名ヘルプを取得できませんでした。'); }
}
function plainSnippet(value) {
  return String(value || '')
    .replace(/\$\{\d+:([^}]*)\}/g, '$1')
    .replace(/\$\{\d+\}/g, '')
    .replace(/\$\d+/g, '')
    .replace(/\r/g, '');
}

function requestInlineFromLsp() {
  if (!lspReady || !lspCurrentUri() || !editor || !ghostEnabled) return;
  const state = editor.state;
  const pos = state.selection.main.head;
  if (!state.selection.main.empty) return;
  const line = state.doc.lineAt(pos);
  const left = state.doc.sliceString(line.from, pos);
  const match = left.match(/[A-Za-z_][\w.]*$/);
  if (!match) return;
  const typedWord = match[0];
  const typed = typedWord.split('.').at(-1) || typedWord;
  if (typed.length < 2) return;
  const snapshot = state.doc.toString();
  const sequence = ++lspGhostSequence;
  clearTimeout(lspGhostTimer);
  lspGhostTimer = setTimeout(async () => {
    try {
      const result = await lspRequest('textDocument/completion', {
        textDocument: { uri: lspCurrentUri() },
        position: toLspPosition(editor.state.doc, pos),
        context: { triggerKind: 1 }
      }, 1100);
      if (sequence !== lspGhostSequence || !editor || editor.state.doc.toString() !== snapshot || editor.state.selection.main.head !== pos) return;
      const items = Array.isArray(result) ? result : result?.items || [];
      const candidates = items
        .filter(item => item && typeof item.label === 'string' && item.label.toLowerCase().startsWith(typed.toLowerCase()) && item.label.length > typed.length)
        .sort((a, b) => String(a.sortText || a.label).localeCompare(String(b.sortText || b.label)));
      const item = candidates[0];
      if (!item) return;
      const raw = plainSnippet(item.textEdit?.newText || item.insertText || item.label);
      let ghost = '';
      if (raw.toLowerCase().startsWith(typed.toLowerCase())) ghost = raw.slice(typed.length);
      else if (item.label.toLowerCase().startsWith(typed.toLowerCase())) ghost = item.label.slice(typed.length);
      if (!ghost && item.kind === 2 && !item.label.endsWith(')')) ghost = `${item.label.slice(typed.length)}(`;
      if (!ghost || ghost.length > 300 || ghost.includes('\u0000')) return;
      const currentGhost = editor.state.field(ghostField);
      // Type-aware LSP suggestions outrank the local heuristic when both are available.
      if (!currentGhost.text || currentGhost.text !== ghost) editor.dispatch({ effects: setGhostEffect.of({ text: ghost, pos }) });
    } catch { /* The local inline engine remains available while LSP is offline. */ }
  }, 180);
}

function buildEditor() {
  const initial = activeDoc();
  editor = new EditorView({
    parent: document.getElementById('editorHost'),
    state: EditorState.create({
      doc: initial.text,
      extensions: [
        basicSetup,
        languageCompartment.of(extForLanguage(initial.language)),
        themeCompartment.of(themeExtension(isLight)),
        wrapCompartment.of(EditorView.lineWrapping),
        indentUnit.of('    '),
        autocompletion({ override: [localContextCompletions, apiCompletionSource, lspCompletionSource], activateOnTyping: true, maxRenderedOptions: 16, defaultKeymap: true }),
        diagnosticsField,
        linter(view => [...view.state.field(diagnosticsField), ...localSyntaxDiagnostics(view.state)], { delay: 180 }),
        ghostField,
        Prec.highest(keymap.of([
          { key: 'Tab', run: view => acceptGhost(view) || acceptCompletion(view) || indentWithTab.run(view) },
          { key: 'Escape', run: view => { const ghost = view.state.field(ghostField); if (!ghost.text) return false; clearGhost(view); return true; } },
          { key: 'Mod-Space', run: view => { requestInlineNow(); return true; } },
          { key: 'F12', run: () => { jumpToDefinition(); return true; } },
          { key: 'Mod-Shift-Space', run: () => { requestSignatureHelp(); return true; } }
        ])),
        keymap.of([...searchKeymap, indentWithTab]),
        EditorView.contentAttributes.of({ autocapitalize: 'off', autocomplete: 'off', autocorrect: 'off', spellcheck: 'false', inputmode: 'text' }),
        EditorView.updateListener.of(update => {
          if (update.docChanged) {
            lastDocChange = Date.now();
            const doc = activeDoc();
            if (doc) { doc.text = update.state.doc.toString(); doc.dirty = true; }
            markDirty();
            scheduleAutosave();
            scheduleInlineSuggestion();
            scheduleLspChange();
            updateDiagnosticCount();
          }
          if (update.selectionSet) { updateCursor(); if (lspReady) requestInlineFromLsp(); }
        })
      ]
    })
  });
  updateCursor();
}

function renderFiles() {
  const list = document.getElementById('fileList');
  list.innerHTML = '';
  docs.forEach(doc => {
    const row = document.createElement('div');
    row.className = `file-row${doc.id === activeId ? ' active' : ''}`;
    const icon = document.createElement('span'); icon.className = 'file-symbol'; icon.textContent = doc.language === 'lua' ? 'λ' : '◆';
    const name = document.createElement('span'); name.textContent = doc.name;
    row.append(icon, name);
    if (doc.dirty) { const dirty = document.createElement('span'); dirty.className = 'file-dirty'; dirty.textContent = '•'; row.append(dirty); }
    row.addEventListener('click', () => switchDoc(doc.id));
    list.append(row);
  });
  const doc = activeDoc();
  if (doc) {
    document.getElementById('topFileName').textContent = doc.name;
    document.getElementById('crumbFile').textContent = doc.name;
    document.querySelector('.tab span:nth-child(2)').textContent = doc.name;
    document.getElementById('languageBtn').textContent = `${doc.language === 'lua' ? 'Lua' : 'Luau'} ▾`;
    document.querySelector('.tab .lua-file-icon').textContent = doc.language === 'lua' ? 'λ' : '◆';
  }
}
function markDirty() {
  const doc = activeDoc();
  document.getElementById('dirtyDot').classList.toggle('visible', Boolean(doc?.dirty));
  renderFiles();
}
function switchDoc(nextId) {
  if (nextId === activeId) { closeSidebar(); return; }
  const current = activeDoc();
  if (current && editor) current.text = editor.state.doc.toString();
  activeId = nextId;
  const doc = activeDoc();
  if (!doc) return;
  fileHandle = doc.handle || null;
  editor.dispatch({
    changes: { from: 0, to: editor.state.doc.length, insert: doc.text },
    effects: [languageCompartment.reconfigure(extForLanguage(doc.language))]
  });
  renderFiles(); markDirty(); updateCursor(); switchLspDocument(doc); closeSidebar(); editor.focus();
}
function newFile() {
  const number = docs.length + 1;
  const doc = { id: id(), name: `untitled-${number}.luau`, text: '', language: 'luau', dirty: false, handle: null };
  docs.push(doc); activeId = doc.id; fileHandle = null;
  if (editor) editor.dispatch({ changes: { from: 0, to: editor.state.doc.length, insert: '' }, effects: [languageCompartment.reconfigure(luau())] });
  renderFiles(); markDirty(); scheduleAutosave(); ensureLspDocument(doc); editor?.focus();
}
function scheduleAutosave() {
  clearTimeout(autosaveTimer);
  autosaveTimer = setTimeout(() => {
    const doc = activeDoc();
    if (doc && editor) doc.text = editor.state.doc.toString();
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ docs, activeId, savedAt: Date.now() }));
      document.getElementById('footerAi').textContent = 'Draft saved on device';
    } catch {
      showToast('端末の保存領域がいっぱいです。ファイルに書き出してください。');
    }
  }, 420);
}
function loadWorkspace() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    if (saved?.docs?.length) {
      docs = saved.docs.map(d => ({ ...d, handle: null, dirty: false }));
      activeId = docs.some(d => d.id === saved.activeId) ? saved.activeId : docs[0].id;
      return;
    }
  } catch { /* recover with starter */ }
  const start = { id: id(), name: 'main.luau', text: STARTER, language: 'luau', dirty: false, handle: null };
  docs = [start]; activeId = start.id;
}
function downloadText(name, text) {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = name; document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
async function saveCurrent(forceSaveAs = false) {
  const doc = activeDoc(); if (!doc || !editor) return;
  doc.text = editor.state.doc.toString();
  const mime = 'text/plain';
  try {
    if (doc.handle && !forceSaveAs) {
      const writable = await doc.handle.createWritable(); await writable.write(new Blob([doc.text], { type: mime })); await writable.close();
    } else if ('showSaveFilePicker' in window) {
      const handle = await window.showSaveFilePicker({
        suggestedName: doc.name,
        types: [{ description: 'Lua / Luau source', accept: { 'text/plain': ['.lua', '.luau'] } }]
      });
      const writable = await handle.createWritable(); await writable.write(new Blob([doc.text], { type: mime })); await writable.close();
      doc.handle = handle; doc.name = handle.name; fileHandle = handle;
    } else {
      downloadText(doc.name, doc.text);
    }
    doc.dirty = false; markDirty(); scheduleAutosave(); showToast('ファイルを保存しました');
  } catch (error) {
    if (error?.name !== 'AbortError') showToast('保存できませんでした。もう一度お試しください。');
  }
}
async function openFile(file) {
  if (!file) return;
  const text = await file.text();
  const language = file.name.toLowerCase().endsWith('.lua') && !file.name.toLowerCase().endsWith('.luau') ? 'lua' : 'luau';
  const doc = { id: id(), name: file.name, text, language, dirty: false, handle: null };
  docs.push(doc); activeId = doc.id; fileHandle = null;
  editor.dispatch({ changes: { from: 0, to: editor.state.doc.length, insert: text }, effects: [languageCompartment.reconfigure(extForLanguage(language))] });
  renderFiles(); markDirty(); scheduleAutosave(); ensureLspDocument(doc); editor.focus();
}

function updateCursor() {
  if (!editor) return;
  const pos = editor.state.selection.main.head;
  const line = editor.state.doc.lineAt(pos);
  document.getElementById('cursorPosition').textContent = `Ln ${line.number}, Col ${pos - line.from + 1}`;
}
function showToast(message) {
  const toast = document.getElementById('toast'); toast.textContent = message; toast.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 2100);
}
function insertText(text) {
  const state = editor.state, sel = state.selection.main;
  editor.dispatch({ changes: { from: sel.from, to: sel.to, insert: text }, selection: { anchor: sel.from + text.length }, scrollIntoView: true });
  editor.focus();
}
function insertSnippet(text) {
  const state = editor.state, sel = state.selection.main;
  const cursor = text.indexOf('\n\t');
  editor.dispatch({ changes: { from: sel.from, to: sel.to, insert: text }, selection: { anchor: cursor >= 0 ? sel.from + cursor + 2 : sel.from + text.length }, scrollIntoView: true });
  editor.focus();
}
function localInlineCandidate(before, after) {
  if (after.trimStart().length && /^[A-Za-z0-9_]/.test(after.trimStart())) return '';
  const line = before.slice(before.lastIndexOf('\n') + 1);
  const trimmed = line.trimStart();
  const indent = line.match(/^\s*/)?.[0] || '';
  const inner = `${indent}    `;
  const block = (closing = 'end') => `\n${inner}\n${indent}${closing}`;

  if (/\b(?:Connect|Once|Promise|BindToRenderStep)\s*\(\s*function\s*\([^)]*\)\s*$/.test(trimmed)) return block('end)');
  if (/\b(?:task\.spawn|task\.defer|task\.delay)\s*\(\s*function\s*\([^)]*\)\s*$/.test(trimmed)) return block('end)');
  if (/^(?:local\s+)?function\s+[A-Za-z_][\w.:]*\s*\([^)]*\)\s*$/.test(trimmed)) return block('end');
  if (/^(?:if|elseif)\s+.+\s+then\s*$/.test(trimmed)) return block('end');
  if (/^(?:for\s+.+\s+do|while\s+.+\s+do|do)\s*$/.test(trimmed)) return block('end');
  if (/^repeat\s*$/.test(trimmed)) return block('until condition');
  if (/^type\s+[A-Za-z_][\w]*\s*=\s*\{\s*$/.test(trimmed)) return `\n${inner}\n${indent}}`;
  if (/^local\s+\w+\s*=\s*pcall\(function\(\)\s*$/.test(trimmed)) return block('end)');

  const getService = before.match(/game:GetService\(["']([A-Za-z0-9_]*)$/);
  if (getService) {
    const service = (apiServiceNames || ['Players','ReplicatedStorage','RunService','TweenService','UserInputService','HttpService']).find(name => name.toLowerCase().startsWith(getService[1].toLowerCase()));
    if (service) return `${service.slice(getService[1].length)}")`;
  }

  const word = before.match(/[A-Za-z_][\w]*$/)?.[0] || '';
  if (!word) return '';
  const localNames = [...before.matchAll(/\b(?:local|const)\s+([A-Za-z_][\w]*)/g)].map(match => match[1]);
  const common = [
    ...LUA_KEYWORDS, ...LUA_BUILTINS, ...ROBLOX_GLOBALS,
    'Players','ReplicatedStorage','RunService','TweenService','UserInputService','Heartbeat','RenderStepped',
    'LocalPlayer','Character','Humanoid','HumanoidRootPart','Position','CFrame','Parent','Name','Connect',
    'WaitForChild','FindFirstChild','GetChildren','GetDescendants','Destroy','Clone','GetService',
    ...localNames
  ];
  const next = [...new Set(common)].find(value => value.toLowerCase().startsWith(word.toLowerCase()) && value.length > word.length);
  return next ? next.slice(word.length) : '';
}

async function localApiGhostCandidate(before, after) {
  if (!platformStatus.apiDbReady || (after.trimStart() && /^[\w]/.test(after.trimStart()))) return '';
  const match = before.match(/([A-Za-z_][\w]*)\.([A-Za-z_]*)$/);
  if (!match) return '';
  const className = inferApiClass(before, match[1]);
  if (!className) return '';
  try {
    const data = await fetchApiCompletionData(new URLSearchParams({ class: className, q: match[2], limit: '20' }));
    const member = (data.results || []).find(item => item.kind === 'member' && item.name.toLowerCase().startsWith(match[2].toLowerCase()) && item.name.length > match[2].length);
    return member ? `${member.name.slice(match[2].length)}${member.memberKind === 'Function' ? '(' : ''}` : '';
  } catch { return ''; }
}

function scheduleInlineSuggestion() {
  clearTimeout(aiTimer);
  if (!editor || !ghostEnabled) return;
  if (aiController) aiController.abort();
  const state = editor.state;
  const pos = state.selection.main.head;
  if (!state.selection.main.empty) return;
  const before = state.doc.sliceString(0, pos);
  const after = state.doc.sliceString(pos);
  const language = activeDoc()?.language || 'luau';
  const documentText = state.doc.toString();
  const show = text => {
    if (!text || !ghostEnabled || !editor || editor.state.doc.toString() !== documentText || editor.state.selection.main.head !== pos) return;
    editor.dispatch({ effects: setGhostEffect.of({ text: text.slice(0, 900), pos }) });
  };
  const localText = localInlineCandidate(before, after);
  if (localText) show(localText);
  else localApiGhostCandidate(before, after).then(show);
  requestInlineFromLsp();
  if (aiEnabled) aiTimer = setTimeout(() => fetchInlineSuggestion(before, after, pos, language, localText), 720);
}

async function fetchInlineSuggestion(before, after, pos, language, fallback = '') {
  const docText = editor.state.doc.toString();
  aiController = new AbortController();
  try {
    const response = await fetch('/api/inline', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prefix: before, suffix: after, language }), signal: aiController.signal
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'AI suggestion failed');
    if (editor.state.doc.toString() !== docText || editor.state.selection.main.head !== pos) return;
    const text = (result.text || '').replace(/\r/g, '').slice(0, 900);
    if (text) editor.dispatch({ effects: setGhostEffect.of({ text, pos }) });
    else if (fallback) editor.dispatch({ effects: setGhostEffect.of({ text: fallback, pos }) });
  } catch (error) {
    if (error.name !== 'AbortError' && fallback && editor.state.doc.toString() === docText && editor.state.selection.main.head === pos) {
      editor.dispatch({ effects: setGhostEffect.of({ text: fallback, pos }) });
    }
  }
}
function requestInlineNow() {
  if (!editor) return;
  clearTimeout(aiTimer); clearGhost();
  const pos = editor.state.selection.main.head;
  const before = editor.state.doc.sliceString(0, pos), after = editor.state.doc.sliceString(pos);
  const fallback = localInlineCandidate(before, after);
  if (fallback) editor.dispatch({ effects: setGhostEffect.of({ text: fallback, pos }) });
  else localApiGhostCandidate(before, after).then(text => {
    if (text && editor.state.selection.main.head === pos) editor.dispatch({ effects: setGhostEffect.of({ text, pos }) });
    else if (!text) showToast('この位置に候補はありません');
  });
  if (aiEnabled) fetchInlineSuggestion(before, after, pos, activeDoc()?.language || 'luau', fallback);
}

async function refreshAIStatus() {
  try {
    let response = await fetch('/api/status'); let data = await response.json();
    if (data.requiresPassword && !data.authenticated) {
      const password = prompt('LuaForge のアクセスパスワードを入力してください');
      if (password) {
        const authResponse = await fetch('/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) });
        if (authResponse.ok) { response = await fetch('/api/status'); data = await response.json(); }
        else showToast('パスワードが違います。エディタはローカルモードで利用できます。');
      }
    }
    aiEnabled = Boolean(data.aiEnabled);
    platformStatus = { ...platformStatus, ...data };
    document.getElementById('lspStatusText') && (document.getElementById('lspStatusText').textContent = data.lspEnabled ? `Luau LSP ${data.lspVersion}` : 'LSP 未起動（オフライン解析）');
    document.getElementById('apiStatusText') && (document.getElementById('apiStatusText').textContent = data.apiDbReady ? `${data.apiClasses} classes / ${data.apiEnums} enums` : 'APIデータ未取得');
    document.getElementById('apiStatusBadge') && (document.getElementById('apiStatusBadge').textContent = data.apiDbReady ? 'API READY' : 'API OFFLINE');
    if (data.apiDbReady) loadApiServiceNames();
  } catch { aiEnabled = false; }
  updateModeBadge();
  document.getElementById('footerAi').textContent = aiEnabled ? 'AI inline suggestions' : 'Local suggestions';
}
function setLanguage(language) {
  const doc = activeDoc(); if (!doc || doc.language === language) return;
  doc.language = language;
  editor.dispatch({ effects: languageCompartment.reconfigure(extForLanguage(language)) });
  renderFiles(); scheduleAutosave(); showToast(`${language === 'lua' ? 'Lua' : 'Luau'} に切り替えました`);
}
function toggleWrap() {
  wrapEnabled = !wrapEnabled;
  editor.dispatch({ effects: wrapCompartment.reconfigure(wrapEnabled ? EditorView.lineWrapping : []) });
  document.getElementById('wrapBtn').classList.toggle('active', wrapEnabled);
}
function toggleTheme() {
  isLight = !isLight;
  editor.dispatch({ effects: themeCompartment.reconfigure(themeExtension(isLight)) });
  document.body.classList.toggle('light-mode', isLight);
  showToast(isLight ? 'ライトテーマ' : 'ダークテーマ');
}
function openFind() {
  const panel = document.getElementById('searchPanel'); panel.hidden = false;
  const input = document.getElementById('searchInput'); input.focus();
}
function findNext() {
  const query = document.getElementById('searchInput').value; if (!query) return;
  const doc = editor.state.doc.toString(); const start = editor.state.selection.main.to;
  let index = doc.indexOf(query, start); if (index < 0) index = doc.indexOf(query);
  if (index >= 0) editor.dispatch({ selection: { anchor: index, head: index + query.length }, scrollIntoView: true });
  else showToast('見つかりませんでした');
  editor.focus();
}
async function copySelection() {
  const sel = editor.state.selection.main;
  const line = editor.state.doc.lineAt(sel.head);
  const text = sel.empty ? line.text : editor.state.sliceDoc(sel.from, sel.to);
  try { await navigator.clipboard.writeText(text); showToast('コピーしました'); }
  catch { showToast('テキストを選択して長押しメニューからコピーしてください'); }
}
async function pasteClipboard() {
  try {
    const text = await navigator.clipboard.readText();
    if (!text) return showToast('クリップボードが空です');
    insertText(text); showToast('ペーストしました');
  } catch { showToast('長押しメニューの「ペースト」を使ってください'); editor.focus(); }
}
function openSettings() {
  const body = document.getElementById('modalBody');
  body.innerHTML = `<p>基本編集機能・オフライン補完・端末内の自動保存は設定不要です。</p><label for="languageSelect">現在のファイルの言語</label><select id="languageSelect"><option value="luau">Luau（推奨）</option><option value="lua">Lua 5.4</option></select><label>Luau Language Server</label><p id="lspStatusText">接続状態を確認中…</p><label>Roblox API Database</label><p id="apiStatusText">取得状態を確認中…</p><span id="apiStatusBadge" class="api-status-badge">CHECKING</span><label>AI補完</label><p>AIキーがなくてもInline Suggestは動作します。AIサービスの追加設定は任意です。APIキーはブラウザに入力せず、Render側の環境変数だけに保存してください。</p><button class="primary" id="saveSettings">適用</button>`;
  body.querySelector('#languageSelect').value = activeDoc()?.language || 'luau';
  body.querySelector('#saveSettings').addEventListener('click', () => { setLanguage(body.querySelector('#languageSelect').value); closeModal(); });
  document.getElementById('modalTitle').textContent = 'Settings';
  showModal();
}
function openMore() {
  const body = document.getElementById('modalBody');
  body.innerHTML = `<p>ファイル操作</p><button class="primary" id="saveAsAction">名前を付けて保存</button><button class="secondary" id="renameAction">ファイル名を変更</button><button class="secondary" id="duplicateAction">複製</button><button class="secondary" id="exportAction">ワークスペースを書き出し</button><p style="margin-top:16px">編集データはブラウザ内に自動保存されています。端末を変える場合はワークスペースの書き出しを使ってください。</p>`;
  document.getElementById('modalTitle').textContent = 'File'; showModal();
  body.querySelector('#saveAsAction').addEventListener('click', () => { closeModal(); saveCurrent(true); });
  body.querySelector('#renameAction').addEventListener('click', () => {
    const doc = activeDoc(); const name = prompt('新しいファイル名', doc.name);
    if (name?.trim()) { doc.name = name.trim().replace(/[\\/:*?"<>|]/g, '_'); renderFiles(); scheduleAutosave(); closeModal(); }
  });
  body.querySelector('#duplicateAction').addEventListener('click', () => {
    const doc = activeDoc(); const copy = { ...doc, id: id(), name: doc.name.replace(/\.(lua|luau)$/i, '') + '-copy.' + doc.language, handle: null, dirty: true };
    docs.push(copy); activeId = copy.id; editor.dispatch({ changes: { from: 0, to: editor.state.doc.length, insert: copy.text }, effects: [languageCompartment.reconfigure(extForLanguage(copy.language))] });
    renderFiles(); markDirty(); scheduleAutosave(); closeModal();
  });
  body.querySelector('#exportAction').addEventListener('click', () => {
    downloadText('luaforge-workspace.json', JSON.stringify({ version: 1, docs: docs.map(({ name, text, language }) => ({ name, text, language })) }, null, 2)); closeModal(); showToast('ワークスペースを出力しました');
  });
}
async function openApiExplorer() {
  const body = document.getElementById('modalBody');
  body.innerHTML = `<p>Roblox Studioの公開APIデータベースを検索します。クラス、プロパティ、関数、イベント、Enumを調べられます。</p><input id="apiSearchInput" type="search" placeholder="例: Players / GetService / Vector3" autocomplete="off" /><div id="apiSearchMeta" class="api-meta">検索ワードを入力してください。</div><div id="apiSearchResults" class="api-results"></div>`;
  document.getElementById('modalTitle').textContent = 'Roblox API Explorer';
  showModal();
  const input = body.querySelector('#apiSearchInput');
  input.focus();
  let timer;
  const run = async () => {
    const query = input.value.trim();
    const results = body.querySelector('#apiSearchResults');
    const meta = body.querySelector('#apiSearchMeta');
    results.innerHTML = '';
    if (!query) { meta.textContent = `${platformStatus.apiClasses || 0} classes · ${platformStatus.apiEnums || 0} enums`; return; }
    meta.textContent = '検索中…';
    try {
      const response = await fetch(`/api/roblox-api?${new URLSearchParams({ q: query, limit: '45' })}`);
      const payload = await response.json();
      meta.textContent = `${payload.source || 'Roblox API'} · ${payload.version || 'version unknown'}`;
      for (const item of payload.results || []) {
        const button = document.createElement('button');
        button.className = 'api-result';
        const title = document.createElement('strong'); title.textContent = item.kind === 'member' ? `${item.className}.${item.name}` : item.name;
        const detail = document.createElement('small'); detail.textContent = item.kind === 'member' ? item.signature : item.detail || (item.kind === 'enum' ? 'Enum' : 'Roblox class');
        button.append(title, detail);
        button.addEventListener('click', () => {
          const text = item.kind === 'member' ? `${item.name}${item.memberKind === 'Function' ? '(' : ''}` : item.name;
          insertText(text); closeModal(); showToast(`${item.name} を挿入しました`);
        });
        results.append(button);
      }
      if (!(payload.results || []).length) meta.textContent = `${meta.textContent} · 該当なし`;
    } catch { meta.textContent = 'API検索を利用できません。'; }
  };
  input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(run, 180); });
  input.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });
}
function changeFontSize(delta) {
  editorFontSize = Math.max(11, Math.min(22, editorFontSize + delta));
  try { localStorage.setItem('luaforge.fontSize', String(editorFontSize)); } catch { /* optional preference */ }
  editor.dispatch({ effects: themeCompartment.reconfigure(themeExtension(isLight)) });
  showToast(`文字サイズ ${editorFontSize}px`);
}

function openQuickMenu() {
  const body = document.getElementById('modalBody');
  body.innerHTML = `<p>スマホ向けクイック操作</p><div class="quick-grid"><button id="quickComment">-- コメント切替</button><button id="quickIndent">→ インデント</button><button id="quickOutdent">← 逆インデント</button><button id="quickSelectAll">全選択</button><button id="quickDuplicate">行を複製</button><button id="quickApi">Roblox API検索</button><button id="quickDefinition">定義へ移動</button><button id="quickSignature">引数ヘルプ</button><button id="quickHover">型・説明を見る</button><button id="quickReferences">参照を検索</button><button id="quickSmaller">文字を小さく A−</button><button id="quickLarger">文字を大きく A＋</button><button id="quickKeyboard">キーボード表示</button><button id="quickSave">保存</button></div><p class="api-meta">Tab: ゴーストテキストを採用 · Esc: 閉じる</p>`;
  document.getElementById('modalTitle').textContent = 'Quick actions'; showModal();
  body.querySelector('#quickComment').addEventListener('click', () => {
    const selection = editor.state.selection.main;
    const line = editor.state.doc.lineAt(selection.from);
    const text = editor.state.sliceDoc(line.from, line.to);
    const next = text.trimStart().startsWith('--') ? text.replace(/^\s*--\s?/, '') : `-- ${text}`;
    editor.dispatch({ changes: { from: line.from, to: line.to, insert: next } }); closeModal(); editor.focus();
  });
  body.querySelector('#quickIndent').addEventListener('click', () => { indentWithTab.run(editor); closeModal(); editor.focus(); });
  body.querySelector('#quickOutdent').addEventListener('click', () => {
    const line = editor.state.doc.lineAt(editor.state.selection.main.head);
    const leading = line.text.match(/^\s{1,4}/)?.[0] || '';
    if (leading) editor.dispatch({ changes: { from: line.from, to: line.from + leading.length, insert: '' } });
    closeModal(); editor.focus();
  });
  body.querySelector('#quickSelectAll').addEventListener('click', () => { editor.dispatch({ selection: { anchor: 0, head: editor.state.doc.length } }); closeModal(); editor.focus(); });
  body.querySelector('#quickDuplicate').addEventListener('click', () => {
    const line = editor.state.doc.lineAt(editor.state.selection.main.head);
    editor.dispatch({ changes: { from: line.to, insert: `\n${line.text}` }, selection: { anchor: line.to + 1 + line.text.length } });
    closeModal(); editor.focus();
  });
  body.querySelector('#quickApi').addEventListener('click', openApiExplorer);
  body.querySelector('#quickDefinition').addEventListener('click', () => { closeModal(); jumpToDefinition(); });
  body.querySelector('#quickSignature').addEventListener('click', () => { closeModal(); requestSignatureHelp(); });
  body.querySelector('#quickHover').addEventListener('click', () => { closeModal(); requestHover(); });
  body.querySelector('#quickReferences').addEventListener('click', () => { closeModal(); findReferences(); });
  body.querySelector('#quickSmaller').addEventListener('click', () => changeFontSize(-1));
  body.querySelector('#quickLarger').addEventListener('click', () => changeFontSize(1));
  body.querySelector('#quickKeyboard').addEventListener('click', () => { closeModal(); editor.focus(); editor.contentDOM.focus(); });
  body.querySelector('#quickSave').addEventListener('click', () => { closeModal(); saveCurrent(); });
}

function showModal() { document.getElementById('modalBackdrop').hidden = false; }
function closeModal() { document.getElementById('modalBackdrop').hidden = true; }
function openSidebar() { document.getElementById('sidebar').classList.add('open'); document.getElementById('sidebarScrim').classList.add('show'); }
function closeSidebar() { document.getElementById('sidebar').classList.remove('open'); document.getElementById('sidebarScrim').classList.remove('show'); }

function wireUI() {
  document.getElementById('newBtn').addEventListener('click', newFile);
  document.getElementById('sidebarNew').addEventListener('click', newFile);
  document.getElementById('tabAdd').addEventListener('click', newFile);
  document.getElementById('openBtn').addEventListener('click', () => document.getElementById('fileInput').click());
  document.getElementById('fileInput').addEventListener('change', async event => { const file = event.target.files?.[0]; if (file) await openFile(file); event.target.value = ''; });
  document.getElementById('saveBtn').addEventListener('click', () => saveCurrent());
  document.getElementById('mobileSaveBtn').addEventListener('click', () => saveCurrent());
  document.getElementById('moreBtn').addEventListener('click', openMore);
  document.getElementById('menuBtn').addEventListener('click', openSidebar);
  document.getElementById('sidebarScrim').addEventListener('click', closeSidebar);
  document.getElementById('sidebarCollapse').addEventListener('click', closeSidebar);
  document.getElementById('settingsBtn').addEventListener('click', openSettings);
  document.getElementById('settingsSide').addEventListener('click', openSettings);
  document.getElementById('modalClose').addEventListener('click', closeModal);
  document.getElementById('modalBackdrop').addEventListener('click', e => { if (e.target.id === 'modalBackdrop') closeModal(); });
  document.getElementById('keyboardBtn').addEventListener('click', () => { editor.focus(); editor.contentDOM.focus(); showToast('キーボードを表示しました'); });
  document.getElementById('undoBtn').addEventListener('click', () => { undo(editor); editor.focus(); });
  document.getElementById('redoBtn').addEventListener('click', () => { redo(editor); editor.focus(); });
  document.getElementById('copyBtn').addEventListener('click', copySelection);
  document.getElementById('pasteBtn').addEventListener('click', pasteClipboard);
  document.getElementById('formatBtn').addEventListener('click', () => { const change = indentRange(editor.state, 0, editor.state.doc.length); editor.dispatch({ changes: change }); editor.focus(); showToast('インデントを整えました'); });
  document.getElementById('findBtn').addEventListener('click', openFind);
  document.getElementById('searchRail').addEventListener('click', openFind);
  document.getElementById('searchNext').addEventListener('click', findNext);
  document.getElementById('searchInput').addEventListener('keydown', e => { if (e.key === 'Enter') findNext(); if (e.key === 'Escape') document.getElementById('searchPanel').hidden = true; });
  document.getElementById('searchClose').addEventListener('click', () => { document.getElementById('searchPanel').hidden = true; editor.focus(); });
  document.getElementById('wrapBtn').addEventListener('click', toggleWrap);
  document.getElementById('apiBtn').addEventListener('click', openApiExplorer);
  document.getElementById('quickMenuBtn').addEventListener('click', openQuickMenu);
  document.getElementById('themeBtn').addEventListener('click', toggleTheme);
  document.getElementById('languageBtn').addEventListener('click', () => setLanguage(activeDoc().language === 'lua' ? 'luau' : 'lua'));
  document.getElementById('ghostToggle').addEventListener('click', e => {
    ghostEnabled = !ghostEnabled; e.currentTarget.classList.toggle('on', ghostEnabled); clearGhost();
    if (ghostEnabled) scheduleInlineSuggestion();
  });
  document.querySelectorAll('.mobile-shortcuts button').forEach(button => button.addEventListener('click', () => insertText(button.dataset.insert)));
  document.getElementById('insertService').addEventListener('click', () => insertSnippet('local Service = game:GetService("ServiceName")'));
  document.getElementById('insertFunction').addEventListener('click', () => insertSnippet('local function name()\n\t\nend'));
  document.getElementById('insertPrint').addEventListener('click', () => insertSnippet('print()'));
  document.querySelector('.tab-close').addEventListener('click', () => {
    if (docs.length <= 1) { newFile(); return; }
    const oldId = activeId;
    const oldUri = lspUris.get(oldId);
    if (oldUri && lspReady) lspNotify('textDocument/didClose', { textDocument: { uri: oldUri } });
    lspUris.delete(oldId);
    docs = docs.filter(doc => doc.id !== oldId);
    activeId = docs[0].id;
    const next = activeDoc();
    editor.dispatch({ changes: { from: 0, to: editor.state.doc.length, insert: next.text }, effects: [languageCompartment.reconfigure(extForLanguage(next.language))] });
    renderFiles(); markDirty(); scheduleAutosave(); switchLspDocument(next);
  });
  document.addEventListener('keydown', event => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 's') { event.preventDefault(); saveCurrent(); }
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'o') { event.preventDefault(); document.getElementById('fileInput').click(); }
  });
}

function syncVisualViewport() {
  const height = window.visualViewport?.height || window.innerHeight;
  document.documentElement.style.setProperty('--app-height', `${Math.max(320, Math.round(height))}px`);
}
syncVisualViewport();
window.visualViewport?.addEventListener('resize', syncVisualViewport, { passive: true });
window.addEventListener('resize', syncVisualViewport, { passive: true });
window.addEventListener('orientationchange', () => setTimeout(syncVisualViewport, 120), { passive: true });
if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}), { once: true });

loadWorkspace();
renderFiles();
buildEditor();
wireUI();
refreshAIStatus();
startLsp();
scheduleAutosave();
