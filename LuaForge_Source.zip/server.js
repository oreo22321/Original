import express from 'express';
import helmet from 'helmet';
import path from 'node:path';
import os from 'node:os';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { WebSocketServer, WebSocket } from 'ws';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 10000);
const MODEL = process.env.OPENAI_MODEL || '';
const LSP_PATH = process.env.LUAFORGE_LSP_PATH || path.join(__dirname, 'bin', 'luau-lsp');
const DEFINITIONS_PATH = process.env.LUAU_DEFINITIONS_PATH || path.join(__dirname, 'data', 'globalTypes.None.d.luau');
const DOCS_PATH = process.env.LUAU_DOCS_PATH || path.join(__dirname, 'data', 'api-docs.en-us.json');
const API_INDEX_PATH = path.join(__dirname, 'data', 'roblox-api-index.json');

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'", 'wss:', 'https://api.openai.com'],
      fontSrc: ["'self'", 'data:', 'https://fonts.gstatic.com'],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: []
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: '6mb' }));

const health = { ok: true, startedAt: Date.now() };
let apiIndex = { source: 'Not downloaded', version: 'offline', classes: [], enums: [], services: [] };
try {
  const parsed = JSON.parse(await fs.readFile(API_INDEX_PATH, 'utf8'));
  if (Array.isArray(parsed.classes)) apiIndex = parsed;
} catch { /* optional setup data */ }

app.get('/health', (_req, res) => res.json(health));

function readCookie(req, name) {
  const cookies = (req.headers.cookie || '').split(';');
  for (const item of cookies) {
    const index = item.indexOf('=');
    if (index < 0) continue;
    if (item.slice(0, index).trim() === name) return decodeURIComponent(item.slice(index + 1).trim());
  }
  return '';
}
function validSession(req) {
  const password = process.env.APP_PASSWORD;
  if (!password) return false;
  const token = readCookie(req, 'luaforge_auth');
  const [timestamp, signature] = token.split('.');
  if (!timestamp || !signature || !/^\d+$/.test(timestamp)) return false;
  const issuedAt = Number(timestamp);
  if (!Number.isFinite(issuedAt) || Date.now() - issuedAt > 7 * 24 * 60 * 60 * 1000 || issuedAt > Date.now() + 60_000) return false;
  const expected = crypto.createHmac('sha256', password).update(timestamp).digest('hex');
  const a = Buffer.from(signature, 'hex');
  const b = Buffer.from(expected, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function createRateLimit(maxRequests, windowMs = 60_000) {
  const buckets = new Map();
  return (req, res, next) => {
    const key = req.ip || req.socket.remoteAddress || 'unknown';
    const now = Date.now();
    const entry = buckets.get(key) || { count: 0, resetAt: now + windowMs };
    if (now > entry.resetAt) { entry.count = 0; entry.resetAt = now + windowMs; }
    entry.count += 1;
    buckets.set(key, entry);
    if (entry.count > maxRequests) return res.status(429).json({ error: 'リクエストが多すぎます。少し待ってください。' });
    return next();
  };
}
const authRateLimit = createRateLimit(12);
const apiSearchRateLimit = createRateLimit(240);
const aiRateLimit = createRateLimit(12);

app.post('/api/auth', authRateLimit, (req, res) => {
  const configured = process.env.APP_PASSWORD;
  if (!configured) return res.json({ ok: true, protected: false });
  const supplied = typeof req.body?.password === 'string' ? req.body.password : '';
  const a = Buffer.from(supplied);
  const b = Buffer.from(configured);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json({ error: 'パスワードが違います。' });
  const timestamp = String(Date.now());
  const signature = crypto.createHmac('sha256', configured).update(timestamp).digest('hex');
  const secure = req.secure ? '; Secure' : '';
  res.setHeader('Set-Cookie', `luaforge_auth=${timestamp}.${signature}; HttpOnly${secure}; SameSite=Strict; Path=/; Max-Age=604800`);
  return res.json({ ok: true });
});

let lspInstalled = false;
try { await fs.access(LSP_PATH); lspInstalled = true; } catch { /* not installed by setup step */ }
let lspVersion = 'not installed';
try { lspVersion = JSON.parse(await fs.readFile(path.join(__dirname, 'data', 'lsp-version.json'), 'utf8')).version || lspVersion; } catch { /* optional */ }
app.get('/api/definition-source', async (req, res) => {
  try {
    const uri = String(req.query.uri || '');
    const line = Math.max(0, Math.min(2_000_000, Number(req.query.line) || 0));
    const target = path.resolve(fileURLToPath(new URL(uri)));
    if (target !== path.resolve(DEFINITIONS_PATH)) return res.status(404).json({ error: 'Definition source is not available for preview.' });
    const source = await fs.readFile(target, 'utf8');
    const lines = source.split(/\r?\n/);
    const start = Math.max(0, line - 10);
    const end = Math.min(lines.length, line + 11);
    return res.json({ name: path.basename(target), startLine: start + 1, selectedLine: line + 1, lines: lines.slice(start, end) });
  } catch { return res.status(400).json({ error: 'Invalid definition location.' }); }
});

app.get('/api/status', (req, res) => {
  const aiConfigured = Boolean(process.env.OPENAI_API_KEY && process.env.APP_PASSWORD && MODEL);
  const authenticated = !process.env.APP_PASSWORD || validSession(req);
  res.json({
    aiEnabled: aiConfigured && authenticated,
    aiConfigured,
    aiModel: aiConfigured ? MODEL : null,
    requiresPassword: Boolean(process.env.APP_PASSWORD) && aiConfigured,
    authenticated,
    lspEnabled: lspInstalled,
    lspVersion,
    apiDbReady: apiIndex.classes.length > 0,
    apiDbSource: apiIndex.source,
    apiDbVersion: apiIndex.version,
    apiClasses: apiIndex.classes.length,
    apiEnums: apiIndex.enums.length
  });
});

function norm(value) { return String(value || '').toLowerCase(); }
function publicSecurity(value) {
  if (value == null || value === '') return true;
  if (typeof value === 'string') return ['none', 'public'].includes(value.toLowerCase());
  if (Array.isArray(value)) return value.every(publicSecurity);
  if (typeof value === 'object') return Object.values(value).every(publicSecurity);
  return false;
}
function memberAccessible(member) { return publicSecurity(member.security); }
const apiClassMap = new Map(apiIndex.classes.map(item => [item.name, item]));
function inheritedMembers(className) {
  const collected = [];
  const seenClasses = new Set();
  const seenMembers = new Set();
  let current = apiClassMap.get(className);
  while (current && !seenClasses.has(current.name)) {
    seenClasses.add(current.name);
    for (const member of current.members || []) {
      if (!memberAccessible(member) || seenMembers.has(member.name)) continue;
      seenMembers.add(member.name); collected.push({ ...member, declaringClass: current.name });
    }
    current = apiClassMap.get(current.superclass);
  }
  return collected;
}
app.get('/api/roblox-api', apiSearchRateLimit, (req, res) => {
  const query = String(req.query.q || '').trim().slice(0, 80);
  const className = String(req.query.class || '').trim().slice(0, 80);
  const limit = Math.min(60, Math.max(1, Number(req.query.limit) || 30));
  if (className) {
    const cls = apiIndex.classes.find(item => item.name === className);
    if (!cls) return res.json({ class: null, results: [] });
    const results = inheritedMembers(cls.name).filter(member => (!query || norm(member.name).includes(norm(query)) || norm(member.signature).includes(norm(query)))).slice(0, limit).map(member => ({ ...member, className: member.declaringClass }));
    return res.json({ class: { name: cls.name, superclass: cls.superclass, tags: cls.tags }, results, source: apiIndex.source, version: apiIndex.version });
  }
  if (!query) return res.json({ services: apiIndex.services.slice(0, 80), classes: apiIndex.classes.slice(0, 80).map(item => ({ name: item.name, superclass: item.superclass })), enums: apiIndex.enums.slice(0, 80).map(item => item.name), source: apiIndex.source, version: apiIndex.version });

  const lower = norm(query);
  const exactClasses = apiIndex.classes
    .filter(item => norm(item.name).includes(lower))
    .slice(0, Math.max(10, Math.floor(limit / 2)))
    .map(item => ({ kind: 'class', name: item.name, detail: item.superclass ? `extends ${item.superclass}` : 'Roblox class', members: item.members.length }));
  const matchingMembers = [];
  for (const cls of apiIndex.classes) {
    for (const member of cls.members) {
      if (!memberAccessible(member)) continue;
      if (norm(member.name).includes(lower) || norm(member.signature).includes(lower)) {
        matchingMembers.push({ kind: 'member', className: cls.name, name: member.name, memberKind: member.kind, signature: member.signature, tags: member.tags });
        if (matchingMembers.length >= limit * 2) break;
      }
    }
    if (matchingMembers.length >= limit * 2) break;
  }
  const matchingEnums = apiIndex.enums.filter(item => norm(item.name).includes(lower)).slice(0, 12).map(item => ({ kind: 'enum', name: item.name, items: item.items.slice(0, 12) }));
  return res.json({ results: [...exactClasses, ...matchingMembers, ...matchingEnums].slice(0, limit), source: apiIndex.source, version: apiIndex.version });
});

function extractText(data) {
  if (typeof data.output_text === 'string') return data.output_text;
  const parts = [];
  for (const item of data.output || []) {
    if (item.type !== 'message') continue;
    for (const content of item.content || []) if (content.type === 'output_text' && typeof content.text === 'string') parts.push(content.text);
  }
  return parts.join('');
}
app.post('/api/inline', aiRateLimit, async (req, res) => {
  if (!process.env.OPENAI_API_KEY || !MODEL || !process.env.APP_PASSWORD) return res.status(503).json({ error: 'AI未設定です。ローカル補完とLuau LSPはそのまま使えます。' });
  if (!validSession(req)) return res.status(401).json({ error: 'AI補完のパスワードが必要です。' });
  const { prefix, suffix = '', language = 'luau' } = req.body || {};
  if (typeof prefix !== 'string' || typeof suffix !== 'string' || prefix.length > 9000 || suffix.length > 2500) return res.status(400).json({ error: 'Invalid completion context.' });
  if (!['lua', 'luau'].includes(language)) return res.status(400).json({ error: 'Unsupported language.' });
  const prompt = [
    `Complete the user's ${language.toUpperCase()} code at the cursor.`,
    'Return ONLY the immediate continuation, including multiple lines when useful. No markdown or explanation.',
    'Do not repeat any text from the suffix. Prefer the smallest coherent continuation.',
    'Use standard Lua/Luau and documented public Roblox Studio APIs only. Never invent APIs.',
    '', '<before_cursor>', prefix.slice(-7000), '</before_cursor>', '<after_cursor>', suffix.slice(0, 1800), '</after_cursor>'
  ].join('\n');
  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: MODEL, max_output_tokens: 420, input: [{ role: 'user', content: [{ type: 'input_text', text: prompt }] }] }),
      signal: AbortSignal.timeout(18_000)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return res.status(502).json({ error: (data?.error?.message || `AI provider returned ${response.status}`).slice(0, 220) });
    let text = extractText(data).replace(/^```(?:lua|luau)?\s*/i, '').replace(/```\s*$/i, '').replace(/^\s+/, '');
    if (text.length > 1000) text = text.slice(0, 1000);
    return res.json({ text });
  } catch (error) {
    return res.status(502).json({ error: error?.name === 'TimeoutError' ? 'AI suggestion timed out.' : 'Could not reach the AI provider.' });
  }
});

// A small per-browser LSP process. Each session is isolated in its own temporary workspace.
const lspSessions = new Map();
const lspWss = new WebSocketServer({ noServer: true, maxPayload: 8 * 1024 * 1024, perMessageDeflate: false });
const maxSessionsPerIp = 1;
const maxSessionsTotal = Math.max(1, Number(process.env.LUAFORGE_MAX_LSP_SESSIONS) || 1);
let pendingLspSessions = 0;

function safeFileName(value) {
  let name = String(value || 'main.luau').replace(/\\/g, '/').replace(/^\/+/, '');
  name = path.posix.normalize(name);
  if (name === '.' || name.startsWith('../') || name.includes('/../')) name = 'main.luau';
  name = name.split('/').filter(part => part && part !== '.' && part !== '..').join('/');
  name = name.replace(/[^A-Za-z0-9_./-]/g, '_').slice(0, 120);
  if (!/\.(lua|luau)$/i.test(name)) name += '.luau';
  return name || 'main.luau';
}
function writeLspFrame(child, json) {
  if (!child || child.killed || !child.stdin.writable) return;
  const body = Buffer.from(JSON.stringify(json), 'utf8');
  child.stdin.write(Buffer.concat([Buffer.from(`Content-Length: ${body.length}\r\n\r\n`), body]));
}
function attachStdoutParser(child, ws) {
  let buffer = Buffer.alloc(0);
  child.stdout.on('data', chunk => {
    buffer = Buffer.concat([buffer, chunk]);
    while (buffer.length) {
      const headerEnd = buffer.indexOf('\r\n\r\n');
      if (headerEnd < 0) break;
      const header = buffer.subarray(0, headerEnd).toString('ascii');
      const lengthMatch = header.match(/Content-Length:\s*(\d+)/i);
      if (!lengthMatch) { buffer = buffer.subarray(headerEnd + 4); continue; }
      const length = Number(lengthMatch[1]);
      const frameEnd = headerEnd + 4 + length;
      if (!Number.isSafeInteger(length) || length < 0 || length > 12 * 1024 * 1024) { ws.close(1011, 'Invalid LSP frame'); return; }
      if (buffer.length < frameEnd) break;
      const message = buffer.subarray(headerEnd + 4, frameEnd).toString('utf8');
      buffer = buffer.subarray(frameEnd);
      if (ws.readyState === WebSocket.OPEN) ws.send(message);
    }
  });
}
async function createLspSession(ws, ip, workspaceDocs) {
  if (!lspInstalled) {
    ws.send(JSON.stringify({ type: 'error', message: 'Luau Language Server is not installed on this deployment. Offline completion is still available.' }));
    return null;
  }
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'luaforge-workspace-'));
  const files = [];
  const inputDocs = Array.isArray(workspaceDocs) ? workspaceDocs.slice(0, 80) : [];
  let totalWorkspaceBytes = 0;
  for (const item of inputDocs) {
    const name = safeFileName(item.name);
    const filePath = path.resolve(dir, name);
    if (!filePath.startsWith(`${dir}${path.sep}`)) continue;
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    const text = typeof item.text === 'string' ? item.text.slice(0, 500_000) : '';
    const bytes = Buffer.byteLength(text, 'utf8');
    if (totalWorkspaceBytes + bytes > 5_000_000) continue;
    totalWorkspaceBytes += bytes;
    await fs.writeFile(filePath, text, 'utf8');
    files.push({ id: String(item.id || ''), name, uri: pathToFileURL(filePath).href });
  }
  if (!files.length) {
    const filePath = path.join(dir, 'main.luau');
    await fs.writeFile(filePath, '', 'utf8');
    files.push({ id: '', name: 'main.luau', uri: pathToFileURL(filePath).href });
  }
  await fs.writeFile(path.join(dir, '.luaurc'), JSON.stringify({ languageMode: 'strict' }, null, 2));
  const args = ['lsp'];
  try { await fs.access(DEFINITIONS_PATH); args.push(`--definitions:@roblox=${DEFINITIONS_PATH}`); } catch { /* built-in LSP types may be available */ }
  try { await fs.access(DOCS_PATH); args.push(`--docs=${DOCS_PATH}`); } catch { /* optional docs */ }
  const child = spawn(LSP_PATH, args, { cwd: dir, stdio: ['pipe', 'pipe', 'pipe'], env: { ...process.env, HOME: os.tmpdir() } });
  const session = { child, dir, files, ip, createdAt: Date.now(), stderr: '' };
  lspSessions.set(ws, session);
  attachStdoutParser(child, ws);
  child.stderr.on('data', chunk => {
    session.stderr = (session.stderr + chunk.toString('utf8')).slice(-4000);
  });
  child.on('error', error => {
    if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'error', message: `Luau LSP could not start: ${error.message}` }));
  });
  child.on('exit', code => {
    if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'serverExit', code, log: session.stderr.slice(-900) }));
  });
  const spawned = await new Promise(resolve => {
    if (child.pid) return resolve(true);
    const timer = setTimeout(() => resolve(false), 2500);
    child.once('spawn', () => { clearTimeout(timer); resolve(true); });
    child.once('error', () => { clearTimeout(timer); resolve(false); });
  });
  if (!spawned || ws.readyState !== WebSocket.OPEN) {
    lspSessions.delete(ws);
    try { child.kill('SIGKILL'); } catch { /* process may not exist */ }
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {});
    return null;
  }
  const rootUri = pathToFileURL(dir.endsWith(path.sep) ? dir : `${dir}${path.sep}`).href;
  ws.send(JSON.stringify({ type: 'ready', rootUri, files, lspVersion }));
  return session;
}

async function handleClientLspMessage(session, ws, raw) {
  let message;
  try { message = JSON.parse(raw); } catch { return; }
  if (!message || typeof message !== 'object') return;
  if (message.type === 'addFile') {
    const name = safeFileName(message.name);
    const filePath = path.resolve(session.dir, name);
    if (!filePath.startsWith(`${session.dir}${path.sep}`)) return;
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, typeof message.text === 'string' ? message.text.slice(0, 500_000) : '', 'utf8');
    const record = { id: String(message.id || ''), name, uri: pathToFileURL(filePath).href };
    const existing = session.files.findIndex(item => item.id === record.id || item.name === record.name);
    if (existing >= 0) session.files[existing] = record; else session.files.push(record);
    if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'fileAdded', ...record }));
    return;
  }
  if (message.type === 'writeFile') {
    const file = session.files.find(item => item.uri === message.uri);
    if (!file || typeof message.text !== 'string') return;
    const target = fileURLToPath(file.uri);
    if (!target.startsWith(`${session.dir}${path.sep}`)) return;
    await fs.writeFile(target, message.text.slice(0, 500_000), 'utf8').catch(() => {});
    return;
  }
  if (message.type === 'jsonrpc' || message.jsonrpc === '2.0') {
    const params = message.params || {};
    const textDoc = params.textDocument;
    if (textDoc?.uri && Array.isArray(params.contentChanges)) {
      const file = session.files.find(item => item.uri === textDoc.uri);
      if (file && typeof params.contentChanges[0]?.text === 'string') {
        fs.writeFile(fileURLToPath(file.uri), params.contentChanges[0].text.slice(0, 500_000), 'utf8').catch(() => {});
      }
    }
    writeLspFrame(session.child, message);
  }
}

lspWss.on('connection', async (ws, req) => {
  const ip = req.headers['x-forwarded-for']?.toString().split(',')[0]?.trim() || req.socket.remoteAddress || 'unknown';
  const activeForIp = [...lspSessions.values()].filter(item => item.ip === ip).length;
  if (activeForIp >= maxSessionsPerIp || lspSessions.size + pendingLspSessions >= maxSessionsTotal) { ws.close(1013, 'Too many editor sessions'); return; }
  let initialized = false;
  let reservation = true;
  pendingLspSessions++;
  const releaseReservation = () => { if (reservation) { reservation = false; pendingLspSessions = Math.max(0, pendingLspSessions - 1); } };
  const handshakeTimer = setTimeout(() => { if (!initialized) ws.close(1008, 'Workspace handshake timeout'); }, 8000);
  ws.on('message', async data => {
    const raw = data.toString();
    let parsed;
    try { parsed = JSON.parse(raw); } catch { return; }
    if (!initialized && parsed?.type === 'workspace') {
      initialized = true;
      clearTimeout(handshakeTimer);
      try { await createLspSession(ws, ip, parsed.docs); }
      catch (error) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'error', message: 'Luau LSP workspace could not be created.' })); }
      finally { releaseReservation(); }
      return;
    }
    const session = lspSessions.get(ws);
    if (session) await handleClientLspMessage(session, ws, raw);
  });
  ws.on('close', async () => {
    clearTimeout(handshakeTimer);
    releaseReservation();
    const session = lspSessions.get(ws);
    if (!session) return;
    lspSessions.delete(ws);
    try { session.child.kill('SIGTERM'); } catch { /* already stopped */ }
    setTimeout(() => { try { session.child.kill('SIGKILL'); } catch { /* ignored */ } }, 1500).unref?.();
    await fs.rm(session.dir, { recursive: true, force: true }).catch(() => {});
  });
  ws.on('error', () => {});
});

app.use(express.static(path.join(__dirname, 'dist'), { extensions: ['html'] }));
app.get(/.*/, (_req, res) => res.sendFile(path.join(__dirname, 'dist', 'index.html')));
const httpServer = (await import('node:http')).createServer(app);
httpServer.on('upgrade', (req, socket, head) => {
  if (req.url?.split('?')[0] !== '/lsp') { socket.destroy(); return; }
  const origin = req.headers.origin;
  const host = req.headers.host;
  if (origin) {
    try { if (new URL(origin).host !== host) { socket.destroy(); return; } } catch { socket.destroy(); return; }
  }
  lspWss.handleUpgrade(req, socket, head, ws => lspWss.emit('connection', ws, req));
});
httpServer.listen(PORT, '0.0.0.0', () => console.log(`LuaForge listening on ${PORT}`));
