import { defineConfig } from 'vite';

export default defineConfig({
  root: 'public',
  publicDir: '../static',
  build: {
    outDir: '../dist',
    emptyOutDir: true,
    sourcemap: false,
    target: 'es2022'
  },
  server: {
    host: '0.0.0.0',
    proxy: {
      '/api': 'http://localhost:10000',
      '/health': 'http://localhost:10000',
      '/lsp': { target: 'ws://localhost:10000', ws: true }
    }
  }
});
