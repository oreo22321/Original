# LuaForge v3 — Render向け Lua / Luau モバイルIDE

LuaForgeは、iPhone / Android / PCのブラウザで使うLua・Luauエディタです。CodeMirror 6を編集画面に使い、Renderのビルド時にLuau Language ServerとRoblox Studio APIデータを自動で取得します。

## まず公開する（設定ほぼ不要）

**必要なもの：GitHubアカウントとRenderアカウント。APIキーは不要です。**

1. このZIPを展開します。
2. GitHubで新しいリポジトリを作り、このフォルダ内のファイル一式をアップロードします。`public` と `scripts` フォルダは、フォルダ構造を保ったまま置いてください。
3. Renderにログインして **New + → Blueprint** を選び、今アップロードしたGitHubリポジトリを接続します。
4. `render.yaml` が自動検出されるので、**Apply** を押します。
5. ビルドが完了すると、Renderが `https://....onrender.com` のURLを発行します。そのURLをSafari / Chromeで開けば使用できます。

### Renderが自動で行うこと

`render.yaml` のBuild Commandに次の処理を設定済みです。

```bash
npm install && npm run setup && npm run build
```

`npm run setup` がLinux用の最新Luau Language Server、Robloxの型定義・APIドキュメント、最新Studio API Dumpを取得します。**通常利用では環境変数・AIキー・手動のLSP設定は必要ありません。** 上流データの取得に失敗した場合もビルドとエディタ起動は継続し、ローカル補完へフォールバックします。

## 主な機能

- Lua / Luauのシンタックスハイライトと言語切り替え
- AI不要のローカル補完、構文テンプレート、Roblox API補完
- Luau LSPによる型解析、エラー・警告診断、補完、ホバー、引数ヘルプ、定義ジャンプ、参照検索
- 最新Roblox Studio API Dumpから生成した公開API検索DB（クラス、メンバー、Enum）
- `GetService()` のサービス名補完と、クラス継承を考慮したメンバー検索
- LSP補完を使ったInline Suggest（ゴーストテキスト）、複数行ブロックのローカル提案
- オプションのAI補完（サーバー側プロキシ）
- 複数ファイル、タブ、ファイル読み込み、`.lua` / `.luau` 書き出し
- 端末内の自動下書き保存、ワークスペースJSON書き出し
- 検索、Undo / Redo、インデント、コピー・ペースト、折り返し
- スマホ向けキーボード操作列、記号ショートカット、文字サイズ調整、タッチ操作
- PWA対応。ホーム画面への追加と、初回オンライン起動後の静的ファイルキャッシュ

## AI補完（任意）

AIを使わなくてもローカル補完とLuau LSPは動作します。AI補完を追加したい場合のみ、RenderのWeb Service → **Environment** に次を設定します。

| Key | Value |
|---|---|
| `OPENAI_API_KEY` | 利用するAPIキー |
| `OPENAI_MODEL` | APIアカウントで利用可能なモデルID |
| `APP_PASSWORD` | AI補完APIを保護するための十分に強いパスワード |

保存後に再デプロイします。ブラウザにはAPIキーを置かず、サーバー側だけで保持します。初回にAIを有効化するときだけパスワード入力が表示されます。AIサービスの利用料金はAPI提供元の料金設定によります。

## スマホでの使い方

- エディタをタップするか、下部の **キーボード** を押すと入力できます。
- 画面下部の記号列は `(){}[] = . : " '` をワンタップ挿入します。
- **操作** メニューから、コメント切替、インデント、全選択、行複製、API検索、定義ジャンプ、型情報、参照検索、文字サイズ調整ができます。
- **保存** は `.lua` / `.luau` ファイルとして書き出します。iOS Safariでファイルへの直接上書きが使えない場合は、ダウンロード後に「ファイル」アプリで移動してください。
- ワークスペースはブラウザの端末内ストレージに保存されます。別端末へ移す場合は **••• → ワークスペースを書き出し** を使ってください。
- Safariでは共有メニューから「ホーム画面に追加」を選ぶとアプリ風に起動できます。

## Roblox Studioプロジェクトとの連携について

LuaForgeはブラウザ上のエディタです。Roblox Studioの公開API定義を参照できますが、StudioのDataModel階層や実際のプロジェクト構成を自動で読み取るには、RojoのsourcemapやStudio Companionのような追加連携が必要です。現在のクラウドワークスペースは一時ディレクトリとしてLSPへ渡しているため、Studio内の実際のインスタンス階層を知っているわけではありません。

## 対応範囲と注意点

- Roblox API DBは公開APIを対象にし、保護レベルが `None` ではないメンバーは検索候補から除外します。
- Executor固有の注入・回避・不正実行APIやスクリプト実行機能は含みません。
- Luau LSPはLuau用です。`.lua` ファイルは構文編集に対応し、LSP側でも解析を有効化していますが、一般Lua 5.4専用の完全なLanguage Serverではありません。
- LSPとAPIデータはRenderのビルド時に取得します。Renderや上流配布元のネットワーク障害時は、ローカル補完・端末内保存を優先します。
- Render Freeはスリープ等の制約があります。個人利用の試用には使えますが、常時応答や複数人での重い利用は保証できません。
- オンラインのLSP接続はサーバーのCPU・メモリを使うため、同時セッション数を制限しています。

## ローカル開発

```bash
npm install
npm run setup
npm run build
npm start
```

開発時はAPIサーバーとViteを別々のターミナルで起動します。

```bash
npm run api
npm run dev
```

Viteは`/api`、`/health`、`/lsp`を`localhost:10000`へプロキシします。
