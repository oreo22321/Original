import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dataDir = path.join(root, 'data');
const binDir = path.join(root, 'bin');
await fs.mkdir(dataDir, { recursive: true });
await fs.mkdir(binDir, { recursive: true });

async function fetchBuffer(url, timeoutMs = 45_000, headers = {}) {
  const response = await fetch(url, {
    headers: { 'user-agent': 'LuaForge/2.x setup', ...headers },
    signal: AbortSignal.timeout(timeoutMs),
    redirect: 'follow'
  });
  if (!response.ok) throw new Error(`${response.status} ${response.statusText} from ${url}`);
  return Buffer.from(await response.arrayBuffer());
}

function platformPattern(name) {
  const n = name.toLowerCase();
  const linux = n.includes('linux');
  const arch = process.arch === 'arm64'
    ? (n.includes('aarch64') || n.includes('arm64'))
    : (n.includes('x86_64') || n.includes('x64') || n.includes('amd64'));
  return linux && arch;
}

async function installLuauLsp() {
  const binaryPath = path.join(binDir, 'luau-lsp');
  try {
    const release = await (await fetch('https://api.github.com/repos/JohnnyMorganz/luau-lsp/releases/latest', {
      headers: { 'accept': 'application/vnd.github+json', 'user-agent': 'LuaForge/2.x setup' },
      signal: AbortSignal.timeout(20_000)
    })).json();
    if (!Array.isArray(release.assets)) throw new Error('GitHub release did not include assets.');
    const candidates = release.assets.filter(asset => platformPattern(asset.name));
    const asset = candidates.find(item => /\.(zip|tar\.gz|tgz)$/i.test(item.name)) || candidates[0];
    if (!asset) throw new Error(`No Linux ${process.arch} release asset was found in luau-lsp ${release.tag_name || 'latest'}.`);
    const archive = await fetchBuffer(asset.browser_download_url, 90_000, { 'accept': 'application/octet-stream' });
    const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'luaforge-lsp-'));
    const archivePath = path.join(tempDir, asset.name);
    await fs.writeFile(archivePath, archive);
    if (/\.zip$/i.test(asset.name)) {
      const result = spawnSync('unzip', ['-q', archivePath, '-d', tempDir], { stdio: 'inherit' });
      if (result.status !== 0) throw new Error('Could not extract luau-lsp ZIP release.');
    } else if (/\.(tar\.gz|tgz)$/i.test(asset.name)) {
      const result = spawnSync('tar', ['-xzf', archivePath, '-C', tempDir], { stdio: 'inherit' });
      if (result.status !== 0) throw new Error('Could not extract luau-lsp tarball.');
    } else {
      await fs.copyFile(archivePath, binaryPath);
    }
    if (!await exists(binaryPath)) {
      const found = await findFile(tempDir, 'luau-lsp');
      if (!found) throw new Error(`The downloaded release did not contain a luau-lsp executable (${asset.name}).`);
      await fs.copyFile(found, binaryPath);
    }
    await fs.chmod(binaryPath, 0o755);
    const version = release.tag_name || 'unknown';
    await fs.writeFile(path.join(dataDir, 'lsp-version.json'), JSON.stringify({ version, asset: asset.name, installedAt: new Date().toISOString() }, null, 2));
    console.log(`[LuaForge] Installed Luau Language Server ${version} (${asset.name}).`);
    return true;
  } catch (error) {
    console.warn(`[LuaForge] Luau LSP download skipped: ${error.message}`);
    console.warn('[LuaForge] The editor will still start with its offline Luau completion and local diagnostics.');
    return false;
  }
}

async function exists(file) {
  try { await fs.access(file); return true; } catch { return false; }
}

async function findFile(dir, wanted) {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  for (const entry of entries) {
    const candidate = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      const found = await findFile(candidate, wanted);
      if (found) return found;
    } else if (entry.isFile() && entry.name === wanted) return candidate;
  }
  return null;
}

async function downloadRobloxDefinitions() {
  const definitionsPath = path.join(dataDir, 'globalTypes.None.d.luau');
  const docsPath = path.join(dataDir, 'api-docs.en-us.json');
  const tasks = [
    ['https://luau-lsp.pages.dev/type-definitions/globalTypes.None.d.luau', definitionsPath],
    ['https://luau-lsp.pages.dev/api-docs/en-us.json', docsPath]
  ];
  const results = await Promise.allSettled(tasks.map(async ([url, destination]) => {
    if (await exists(destination) && (await fs.stat(destination)).size > 1000) return;
    const content = await fetchBuffer(url, 45_000);
    if (content.length < 1000) throw new Error(`Downloaded file was unexpectedly small: ${url}`);
    await fs.writeFile(destination, content);
  }));
  for (let i = 0; i < results.length; i++) {
    if (results[i].status === 'fulfilled') console.log(`[LuaForge] Roblox definitions/docs ready: ${path.basename(tasks[i][1])}`);
    else console.warn(`[LuaForge] Could not fetch ${path.basename(tasks[i][1])}: ${results[i].reason?.message || results[i].reason}`);
  }
  return { definitionsPath, docsPath };
}

function typeName(value) {
  if (!value) return 'unknown';
  if (typeof value === 'string') return value;
  if (Array.isArray(value)) return value.map(typeName).join(' | ');
  if (typeof value === 'object') return value.Name || value.Category || 'unknown';
  return String(value);
}

function isPublicSecurity(value) {
  if (value == null || value === '') return true;
  if (typeof value === 'string') return value.toLowerCase() === 'none' || value.toLowerCase() === 'public';
  if (Array.isArray(value)) return value.every(isPublicSecurity);
  if (typeof value === 'object') return Object.values(value).every(isPublicSecurity);
  return false;
}

function memberSignature(member) {
  const params = (member.Parameters || []).map(param => `${param.Name}: ${typeName(param.Type)}`).join(', ');
  const returnType = member.ReturnType ? typeName(member.ReturnType) : '';
  if (member.MemberType === 'Function') return `${member.Name}(${params})${returnType ? `: ${returnType}` : ''}`;
  if (member.MemberType === 'Event') return `${member.Name}(${params})`;
  if (member.MemberType === 'Property') return `${member.Name}: ${typeName(member.ValueType)}`;
  return member.Name;
}

function normalizeApiDump(dump, version) {
  const classes = (dump.Classes || []).filter(item => isPublicSecurity(item.Security)).map(item => ({
    name: item.Name,
    superclass: item.Superclass || '',
    tags: Array.isArray(item.Tags) ? item.Tags : [],
    members: (item.Members || []).filter(member => isPublicSecurity(member.Security)).map(member => ({
      name: member.Name,
      kind: member.MemberType || 'Member',
      signature: memberSignature(member),
      tags: Array.isArray(member.Tags) ? member.Tags : [],
      security: member.Security || null,
      summary: ''
    }))
  }));
  const enums = (dump.Enums || []).map(item => ({
    name: item.Name,
    items: (item.Items || []).map(entry => entry.Name)
  }));
  const services = classes.filter(item => item.tags.includes('Service') || item.name === 'Workspace').map(item => item.name).sort();
  return { source: 'Roblox Studio API Dump', version, fetchedAt: new Date().toISOString(), classes, enums, services };
}

function fallbackFromDefinitions(source) {
  const classes = [];
  let current = null;
  for (const line of source.split(/\r?\n/)) {
    const classMatch = line.match(/^\s*declare\s+class\s+([A-Za-z_][\w]*)(?:\s+extends\s+([A-Za-z_][\w]*))?/);
    if (classMatch) {
      current = { name: classMatch[1], superclass: classMatch[2] || '', tags: [], members: [] };
      classes.push(current);
      continue;
    }
    if (current) {
      if (/^\S/.test(line) && line.trim() && !line.trim().startsWith('--')) current = null;
      else {
        const member = line.match(/^\s{2,}(?:function\s+)?([A-Za-z_][\w]*)\s*([:(])/);
        if (member) current.members.push({ name: member[1], kind: member[2] === '(' || member[2] === ':' ? 'Member' : 'Member', signature: member[0].trim(), tags: [], security: null, summary: '' });
      }
    }
  }
  return { source: 'Luau LSP Roblox definitions fallback', version: 'bundled-definition', fetchedAt: new Date().toISOString(), classes, enums: [], services: [] };
}

async function fetchRobloxApi() {
  const output = path.join(dataDir, 'roblox-api-index.json');
  try {
    const version = (await fetchBuffer('https://setup.rbxcdn.com/versionQTStudio', 20_000)).toString('utf8').trim();
    if (!/^[A-Za-z0-9_-]{8,100}$/.test(version)) throw new Error('Invalid Studio version response.');
    const raw = await fetchBuffer(`https://setup.rbxcdn.com/${version}-API-Dump.json`, 90_000);
    const dump = JSON.parse(raw.toString('utf8'));
    const normalized = normalizeApiDump(dump, version);
    if (!normalized.classes.length) throw new Error('The official API dump did not contain classes.');
    await fs.writeFile(output, JSON.stringify(normalized));
    console.log(`[LuaForge] Indexed Roblox Studio API ${version}: ${normalized.classes.length} classes, ${normalized.enums.length} enums.`);
    return;
  } catch (error) {
    console.warn(`[LuaForge] Official Studio API dump download skipped: ${error.message}`);
  }
  try {
    const defPath = path.join(dataDir, 'globalTypes.None.d.luau');
    const source = await fs.readFile(defPath, 'utf8');
    const fallback = fallbackFromDefinitions(source);
    if (fallback.classes.length) {
      await fs.writeFile(output, JSON.stringify(fallback));
      console.log(`[LuaForge] Created API search fallback from ${fallback.classes.length} Luau class definitions.`);
    }
  } catch { /* no network and no cached definitions: local completion remains available */ }
}

await installLuauLsp();
await downloadRobloxDefinitions();
await fetchRobloxApi();
